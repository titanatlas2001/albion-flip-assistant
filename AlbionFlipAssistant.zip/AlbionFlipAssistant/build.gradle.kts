// Proyecto: Albion Flip Assistant
// Complemento de análisis de mercado para Albion Online (móvil)
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
