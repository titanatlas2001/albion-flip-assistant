package com.albionflip.assistant.flips

import android.content.Context
import android.content.SharedPreferences
import com.albionflip.assistant.data.AodpClient

/**
 * Ajustes del análisis de flippin, persistidos en SharedPreferences.
 * Todo es editable desde la pestaña Ajustes de la app.
 */
class FlipSettings(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("flip_settings", Context.MODE_PRIVATE)

    private fun bool(key: String, def: Boolean): Boolean = prefs.getBoolean(key, def)
    private fun setBool(key: String, v: Boolean) = prefs.edit().putBoolean(key, v).apply()
    private fun dbl(key: String, def: Double): Double =
        java.lang.Double.longBitsToDouble(prefs.getLong(key, def.toRawBits()))
    private fun setDbl(key: String, v: Double) = prefs.edit().putLong(key, v.toRawBits()).apply()

    // ── Rutas activas ──────────────────────────────────────────────────────
    /** Mercado Negro: comprar en ciudades → vender a las órdenes de compra del M. Negro. */
    var routeBM: Boolean
        get() = bool("route_bm", true)
        set(v) = setBool("route_bm", v)

    /** Arbitraje Caerleon ↔ ciudades reales (ambas direcciones). */
    var routeCaerleon: Boolean
        get() = bool("route_cae", true)
        set(v) = setBool("route_cae", v)

    /** Encantamientos: activa ⇒ los items encantados (1-3) se etiquetan como ruta ENC;
     *  desactivada ⇒ los items encantados se excluyen del análisis. */
    var routeEnchant: Boolean
        get() = bool("route_ench", true)
        set(v) = setBool("route_ench", v)

    // ── Umbrales de alerta ─────────────────────────────────────────────────
    /** Ganancia mínima en plata para que una oferta entre en la lista y dispare alerta. */
    var minProfit: Long
        get() = prefs.getLong("min_profit", 20_000L)
        set(v) = prefs.edit().putLong("min_profit", v).apply()

    /** Margen mínimo (beneficio / costo de compra) en porcentaje. */
    var minMarginPct: Double
        get() = dbl("min_margin", 0.0)
        set(v) = setDbl("min_margin", v)

    // ── Impuestos y tasas (configurables; revisa los valores vigentes del juego) ──
    /** Impuesto de venta (%) al vender contra una orden de compra. */
    var salesTaxPct: Double
        get() = dbl("sales_tax", 3.0)
        set(v) = setDbl("sales_tax", v)

    /** Tasa de publicación (%) al crear órdenes de venta (dirección inversa de Caerleon). */
    var setupFeePct: Double
        get() = dbl("setup_fee", 2.5)
        set(v) = setDbl("setup_fee", v)

    // ── Ciudades de origen (compra) ────────────────────────────────────────
    var cityThetford: Boolean
        get() = bool("city_0007", true)
        set(v) = setBool("city_0007", v)

    var cityLymhurst: Boolean
        get() = bool("city_1002", true)
        set(v) = setBool("city_1002", v)

    var cityBridgewatch: Boolean
        get() = bool("city_2004", true)
        set(v) = setBool("city_2004", v)

    var cityMartlock: Boolean
        get() = bool("city_3008", true)
        set(v) = setBool("city_3008", v)

    var cityFortSterling: Boolean
        get() = bool("city_4002", true)
        set(v) = setBool("city_4002", v)

    var cityBrecilien: Boolean
        get() = bool("city_5003", true)
        set(v) = setBool("city_5003", v)

    var cityCaerleonAsSource: Boolean
        get() = bool("city_3005", true)
        set(v) = setBool("city_3005", v)

    /** IDs de ciudades de origen activas (donde la app busca precios de compra). */
    val sourceCities: List<String>
        get() {
            val out = ArrayList<String>(7)
            if (cityThetford) out.add("0007")
            if (cityLymhurst) out.add("1002")
            if (cityBridgewatch) out.add("2004")
            if (cityMartlock) out.add("3008")
            if (cityFortSterling) out.add("4002")
            if (cityBrecilien) out.add("5003")
            if (cityCaerleonAsSource) out.add("3005")
            return out
        }

    // ── AODP ───────────────────────────────────────────────────────────────
    var aodpEnabled: Boolean
        get() = bool("aodp_enabled", true)
        set(v) = setBool("aodp_enabled", v)

    var aodpServer: String
        get() = prefs.getString("aodp_server", AodpClient.SERVER_WEST) ?: AodpClient.SERVER_WEST
        set(v) = prefs.edit().putString("aodp_server", v).apply()

    var notificationsEnabled: Boolean
        get() = bool("notifications", true)
        set(v) = setBool("notifications", v)
}
