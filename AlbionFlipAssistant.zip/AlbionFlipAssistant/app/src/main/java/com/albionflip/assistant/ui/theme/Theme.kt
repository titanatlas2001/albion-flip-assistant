package com.albionflip.assistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Paleta inspirada en el mercado de Albion: oscuro, oro y verde plata
val Gold = Color(0xFFE8B93E)
val GoldDark = Color(0xFF8A6D1E)
val GreenSilver = Color(0xFF7FD1AE)
val RedLoss = Color(0xFFD96C4F)
val BgDark = Color(0xFF101418)
val SurfaceDark = Color(0xFF1A2026)
val SurfaceCard = Color(0xFF232B33)

private val DarkScheme = darkColorScheme(
    primary = Gold,
    onPrimary = Color(0xFF1A1405),
    secondary = GreenSilver,
    onSecondary = Color(0xFF06231A),
    background = BgDark,
    onBackground = Color(0xFFE8EAED),
    surface = SurfaceDark,
    onSurface = Color(0xFFE8EAED),
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = Color(0xFFC3CAD1),
    error = RedLoss
)

private val LightScheme = lightColorScheme(
    primary = GoldDark,
    onPrimary = Color.White,
    secondary = Color(0xFF2E7D63),
    onSecondary = Color.White
)

@Composable
fun AlbionFlipTheme(content: @Composable () -> Unit) {
    // La app está pensada para usarse mientras se juega: tema oscuro siempre
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
