package com.albionflip.assistant.capture

import android.net.VpnService
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.nio.channels.SocketChannel
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Router de paquetes de la VPN local.
 *
 * - Lee paquetes IPv4 del dispositivo TUN.
 * - UDP: crea un canal de datagramas protegido por flujo (NAT transparente) y
 *   reenvía el tráfico; cada payload UDP se pasa a [onUdpPayload] ANTES de
 *   reenviarlo (ahí vive la captura Photon de Albion).
 * - TCP: implementa un proxy TCP mínimo (handshake, renumeración de secuencia,
 *   control de flujo, FIN/RST) que conecta con el destino real mediante un
 *   socket protegido.
 *
 * Patrón estándar de las VPN de captura sin root (mismo enfoque que ToyVpn/PCAPdroid).
 */
class PacketRouter(
    private val tunIn: FileInputStream,
    private val tunOut: FileOutputStream,
    private val vpn: VpnService,
    private val onUdpPayload: (payload: ByteArray) -> Unit,
    private val onError: (String) -> Unit
) {
    private val running = AtomicBoolean(false)
    private lateinit var selector: Selector
    private var readerThread: Thread? = null
    private var selectorThread: Thread? = null
    private var writerThread: Thread? = null
    private var cleanerThread: Thread? = null

    private val writeQueue = LinkedBlockingQueue<ByteArray>(8192)
    private val udpFlows = ConcurrentHashMap<String, DatagramChannel>()
    private val udpLastUse = ConcurrentHashMap<String, Long>()
    private val tcpFlows = ConcurrentHashMap<String, TcpFlow>()
    private val random = Random()

    // ── Ciclo de vida ──────────────────────────────────────────────────────

    fun start() {
        if (!running.compareAndSet(false, true)) return
        selector = Selector.open()

        writerThread = Thread({
            try {
                while (running.get()) {
                    val pkt = writeQueue.poll(500, TimeUnit.MILLISECONDS) ?: continue
                    try {
                        tunOut.write(pkt)
                    } catch (_: Exception) {
                    }
                }
            } catch (_: InterruptedException) {
            }
        }, "tun-writer")
        writerThread?.start()

        readerThread = Thread({ readLoop() }, "tun-reader")
        readerThread?.start()

        selectorThread = Thread({ selectorLoop() }, "net-selector")
        selectorThread?.start()

        cleanerThread = Thread({
            while (running.get()) {
                try {
                    Thread.sleep(30_000)
                    val now = System.currentTimeMillis()
                    for ((key, ch) in udpFlows) {
                        val last = udpLastUse[key] ?: now
                        if (now - last > 120_000) {
                            udpFlows.remove(key)
                            udpLastUse.remove(key)
                            try { ch.close() } catch (_: IOException) {}
                        }
                    }
                    for ((key, flow) in tcpFlows) {
                        if (now - flow.lastActivity > 300_000) {
                            tcpFlows.remove(key)
                            flow.hardClose()
                        }
                    }
                } catch (_: InterruptedException) {
                    return@Thread
                }
            }
        }, "flow-cleaner")
        cleanerThread?.start()
    }

    fun stop() {
        running.set(false)
        try { selector.wakeup() } catch (_: Exception) {}
        try { selector.close() } catch (_: IOException) {}
        for (ch in udpFlows.values) try { ch.close() } catch (_: IOException) {}
        udpFlows.clear()
        for (f in tcpFlows.values) f.hardClose()
        tcpFlows.clear()
        readerThread?.interrupt()
        selectorThread?.interrupt()
        writerThread?.interrupt()
        cleanerThread?.interrupt()
    }

    // ── Lectura del TUN ────────────────────────────────────────────────────

    private fun readLoop() {
        val buffer = ByteArray(65535)
        try {
            while (running.get()) {
                val n = tunIn.read(buffer)   // lectura bloqueante del dispositivo TUN
                if (n <= 0) continue
                val packet = buffer.copyOfRange(0, n)
                handleIpPacket(packet)
            }
        } catch (e: Exception) {
            if (running.get()) onError("Lectura TUN interrumpida: ${e.message}")
        }
    }

    private fun handleIpPacket(packet: ByteArray) {
        if (packet.size < 20) return
        val version = (packet[0].toInt() shr 4) and 0xF
        if (version != 4) return                                    // solo IPv4
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (packet.size < ihl) return
        val totalLength = u16(packet, 2)
        if (totalLength < ihl || totalLength > packet.size) return
        val flagsFrag = u16(packet, 6)
        if (flagsFrag and 0x3FFF != 0) return                       // fragmentos IP: fuera de alcance
        val protocol = packet[9].toInt() and 0xFF
        val srcIp = u32(packet, 12)
        val dstIp = u32(packet, 16)

        when (protocol) {
            PROTO_UDP -> handleUdp(packet, ihl, totalLength, srcIp, dstIp)
            PROTO_TCP -> handleTcp(packet, ihl, totalLength, srcIp, dstIp)
            else -> Unit // ICMP y otros: se descartan (el juego no los necesita)
        }
    }

    // ── UDP ────────────────────────────────────────────────────────────────

    private fun handleUdp(packet: ByteArray, ihl: Int, totalLength: Int, srcIp: Int, dstIp: Int) {
        val udpStart = ihl
        if (totalLength < udpStart + 8) return
        val srcPort = u16(packet, udpStart)
        val dstPort = u16(packet, udpStart + 2)
        val udpLength = u16(packet, udpStart + 4)
        val payloadLen = udpLength - 8
        if (payloadLen <= 0 || udpStart + 8 + payloadLen > packet.size) return
        val payload = packet.copyOfRange(udpStart + 8, udpStart + 8 + payloadLen)

        // Captura Photon de Albion (antes de reenviar; la validación del
        // protocolo ocurre dentro del parser y es barata para tráfico ajeno).
        try {
            onUdpPayload(payload)
        } catch (_: Exception) {
        }

        val key = "$srcIp:$srcPort-$dstIp:$dstPort"
        udpLastUse[key] = System.currentTimeMillis()
        var channel: DatagramChannel? = udpFlows[key]
        if (channel == null) {
            try {
                val ch = DatagramChannel.open()
                ch.configureBlocking(false)
                vpn.protect(ch.socket())
                ch.connect(InetSocketAddress(intToIp(dstIp), dstPort))
                ch.register(selector, SelectionKey.OP_READ, key)
                udpFlows[key] = ch
                channel = ch
            } catch (e: Exception) {
                try { udpFlows.remove(key) } catch (_: Exception) {}
                onError("Error abriendo flujo UDP: ${e.message}")
                return
            }
        }
        try {
            channel?.send(ByteBuffer.wrap(payload), InetSocketAddress(intToIp(dstIp), dstPort))
        } catch (_: Exception) {
        }
    }

    /** Respuesta UDP del canal real → paquete IP hacia el TUN. */
    private fun onUdpFlowReadable(key: String, channel: DatagramChannel) {
        val buf = ByteBuffer.allocate(65535)
        val remote: InetSocketAddress = try {
            channel.receive(buf) as? InetSocketAddress ?: return
        } catch (_: Exception) {
            return
        }
        val payloadLen = buf.position()
        if (payloadLen <= 0) return
        val payload = buf.array().copyOfRange(0, payloadLen)

        // key = "srcIp:srcPort-dstIp:dstPort" (cliente → servidor original)
        val sep = key.indexOf('-')
        if (sep < 0) return
        val clientAddr = key.substring(0, sep).split(":")
        if (clientAddr.size != 2) return
        val clientIp = clientAddr[0].toIntOrNull() ?: return
        val clientPort = clientAddr[1].toIntOrNull() ?: return
        val serverIp = ipToInt(remote.address.address)
        val serverPort = remote.port

        val udp = buildUdpPacket(serverPort, clientPort, payload)
        enqueue(buildIpPacket(serverIp, clientIp, PROTO_UDP, udp))
    }

    // ── TCP ────────────────────────────────────────────────────────────────

    private fun handleTcp(packet: ByteArray, ihl: Int, totalLength: Int, srcIp: Int, dstIp: Int) {
        val tcpStart = ihl
        if (totalLength < tcpStart + 20) return
        val srcPort = u16(packet, tcpStart)
        val dstPort = u16(packet, tcpStart + 2)
        val seq = u32(packet, tcpStart + 4).toLong() and 0xFFFFFFFFL
        val ack = u32(packet, tcpStart + 8).toLong() and 0xFFFFFFFFL
        val dataOffsetWords = (packet[tcpStart + 12].toInt() shr 4) and 0xF
        val tcpHeaderLen = dataOffsetWords * 4
        if (tcpHeaderLen < 20 || totalLength < tcpStart + tcpHeaderLen) return
        val flags = packet[tcpStart + 13].toInt() and 0xFF
        val window = u16(packet, tcpStart + 14)
        val payloadLen = totalLength - tcpStart - tcpHeaderLen
        val payload = if (payloadLen > 0)
            packet.copyOfRange(tcpStart + tcpHeaderLen, tcpStart + tcpHeaderLen + payloadLen)
        else ByteArray(0)

        val key = "$srcIp:$srcPort-$dstIp:$dstPort"
        val hasSyn = flags and FLAG_SYN != 0
        val hasAck = flags and FLAG_ACK != 0
        val hasRst = flags and FLAG_RST != 0

        var flow = tcpFlows[key]
        if (hasSyn && !hasAck && flow == null) {
            if (hasRst) return
            flow = TcpFlow(key, srcIp, srcPort, dstIp, dstPort, seq, random.nextInt().toLong() and 0xFFFFFFFFL)
            tcpFlows[key] = flow
        }
        val f = flow ?: return
        f.lastActivity = System.currentTimeMillis()

        if (hasRst) {
            f.hardClose()
            tcpFlows.remove(key)
            return
        }

        synchronized(f) {
            if (hasSyn && !hasAck) {
                // SYN (o su retransmisión): reenviar SYN-ACK y conectar al servidor real
                f.sendSynAck()
                if (!f.connectStarted) f.connectToServer()
                return
            }

            if (hasAck) {
                if (window > 0) f.clientWindow = window
                f.synAcked = true
                if (payload.isNotEmpty()) {
                    f.onClientData(seq, payload)
                } else {
                    f.onClientAck(ack)
                }
                if (flags and FLAG_FIN != 0) {
                    f.onClientFin()
                }
            }
        }
    }

    private fun onTcpFlowReadable(flow: TcpFlow) {
        synchronized(flow) {
            if (flow.closed || !flow.synAcked) return
            val channel = flow.serverChannel ?: return
            val buf = ByteBuffer.allocate(16384)
            val read: Int = try {
                channel.read(buf)
            } catch (_: Exception) {
                flow.sendRst()
                flow.hardClose()
                tcpFlows.remove(flow.key)
                return
            }
            if (read < 0) {
                flow.onServerEof()
                return
            }
            if (read == 0) return
            flow.onServerData(buf.array().copyOfRange(0, read))
        }
    }

    private fun onTcpConnectable(flow: TcpFlow) {
        synchronized(flow) {
            if (flow.closed) return
            val channel = flow.serverChannel ?: return
            try {
                if (channel.finishConnect()) {
                    flow.connected = true
                    channel.register(selector, SelectionKey.OP_READ, flow)
                    flow.flushPendingToServer()
                } else {
                    flow.sendRst()
                    flow.hardClose()
                    tcpFlows.remove(flow.key)
                }
            } catch (_: Exception) {
                // conexión al servidor real falló: RST al cliente
                flow.sendRst()
                flow.hardClose()
                tcpFlows.remove(flow.key)
            }
        }
    }

    // ── Bucle del selector (eventos de red) ───────────────────────────────

    private fun selectorLoop() {
        try {
            while (running.get()) {
                selector.select(500)
                if (!running.get()) break
                val it = selector.selectedKeys().iterator()
                while (it.hasNext()) {
                    val key = it.next()
                    it.remove()
                    try {
                        when {
                            key.isConnectable -> {
                                (key.attachment() as? TcpFlow)?.let { onTcpConnectable(it) }
                            }
                            key.isReadable -> {
                                when (val att = key.attachment()) {
                                    is String -> (key.channel() as DatagramChannel)?.let {
                                        onUdpFlowReadable(att, it)
                                    }
                                    is TcpFlow -> onTcpFlowReadable(att)
                                }
                            }
                        }
                    } catch (_: Exception) {
                        try { key.cancel() } catch (_: Exception) {}
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun enqueue(packet: ByteArray) {
        // cola llena: se descarta; TCP retransmite y UDP es tolerante a pérdida
        writeQueue.offer(packet)
    }

    // ── Flujo TCP ──────────────────────────────────────────────────────────

    inner class TcpFlow(
        val key: String,
        val clientIp: Int,
        val clientPort: Int,
        val serverIp: Int,
        val serverPort: Int,
        clientIsn: Long,
        ourIsn: Long
    ) {
        var lastActivity: Long = System.currentTimeMillis()

        var synAcked = false
        var connectStarted = false
        var connected = false
        var closed = false

        // Nuestro lado falso: seq = numeración que inventamos; ack = lo que esperamos del cliente
        var clientNextSeq: Long = clientIsn + 1      // próximo byte esperado del cliente
        var ourNextSeq: Long = ourIsn + 1            // próximo seq que usaremos hacia el cliente
        var lastClientAck: Long = ourIsn + 1         // último byte confirmado por el cliente
        var clientWindow: Int = 65535

        var serverChannel: SocketChannel? = null
        private val pendingToServer = ArrayList<ByteArray>()
        private val pendingToClient = ArrayList<ByteArray>()
        private var serverEof = false
        private var clientFin = false

        fun connectToServer() {
            connectStarted = true
            try {
                val ch = SocketChannel.open()
                ch.configureBlocking(false)
                vpn.protect(ch.socket())
                ch.connect(InetSocketAddress(intToIp(serverIp), serverPort))
                serverChannel = ch
                ch.register(selector, SelectionKey.OP_CONNECT, this)
            } catch (_: Exception) {
                sendRst()
                hardClose()
                tcpFlows.remove(key)
            }
        }

        fun sendSynAck() {
            val opts = byteArrayOf(0x02, 0x04, 0x05, 0xB4.toByte())  // MSS 1460
            sendToClient(ByteArray(0), FLAG_SYN or FLAG_ACK, opts)
        }

        fun onClientData(seq: Long, data: ByteArray) {
            if (seq == clientNextSeq) {
                if (!connected || pendingToServer.isNotEmpty()) {
                    // mantener el orden: primero lo encolado, después lo nuevo
                    pendingToServer.add(data)
                    if (connected) flushPendingToServer()
                    return
                }
                val written = writeToServer(data)
                if (written > 0) clientNextSeq += written
                if (written < data.size) {
                    pendingToServer.add(data.copyOfRange(written, data.size))
                }
                sendAck()
            } else if (seq < clientNextSeq) {
                sendAck()      // retransmisión ya recibida: re-ACK
            } else {
                sendAck()      // hueco imposible en TCP: pedir retransmisión implícita
            }
        }

        fun onClientAck(ack: Long) {
            lastClientAck = ack
            flushPendingToClient()
        }

        fun onClientFin() {
            clientFin = true
            try { serverChannel?.shutdownOutput() } catch (_: Exception) {}
            sendAck()
            if (serverEof) sendFin()
            if (clientFin && serverEof && pendingToClient.isEmpty()) cleanup()
        }

        fun onServerEof() {
            serverEof = true
            try { serverChannel?.close() } catch (_: Exception) {}
            if (clientFin) {
                cleanup()
            } else {
                sendFin()
            }
        }

        fun onServerData(data: ByteArray) {
            pendingToClient.add(data)
            flushPendingToClient()
        }

        /** Envía hacia el cliente respetando su ventana anunciada. */
        private fun flushPendingToClient() {
            var i = 0
            while (i < pendingToClient.size) {
                val outstanding = ourNextSeq - lastClientAck
                if (outstanding >= 65535L) break    // control de flujo: esperar ACKs
                var chunk = pendingToClient[i]
                while (chunk.isNotEmpty()) {
                    val take = minOf(chunk.size, 16000)
                    val part = if (take == chunk.size) chunk else chunk.copyOfRange(0, take)
                    val lastPart = take == chunk.size
                    val flags = if (lastPart) FLAG_PSH or FLAG_ACK else FLAG_ACK
                    sendToClient(part, flags, ByteArray(0))
                    if (lastPart) break
                    chunk = chunk.copyOfRange(take, chunk.size)
                }
                i++
            }
            if (i >= pendingToClient.size) pendingToClient.clear() else pendingToClient.subList(0, i).clear()
        }

        private fun sendToClient(payload: ByteArray, flags: Int, options: ByteArray) {
            val tcp = buildTcpPacket(serverIp, clientIp, serverPort, clientPort,
                ourNextSeq, clientNextSeq, flags, 65535, options, payload)
            // SYN y FIN consumen un número de secuencia; los datos, su longitud
            if (flags and FLAG_SYN != 0 || flags and FLAG_FIN != 0) {
                ourNextSeq += if (payload.isEmpty()) 1 else (payload.size + 1)
            } else {
                ourNextSeq += payload.size
            }
            enqueue(buildIpPacket(serverIp, clientIp, PROTO_TCP, tcp))
        }

        private fun flushPendingToServer() {
            var i = 0
            while (i < pendingToServer.size) {
                val data = pendingToServer[i]
                val written = try {
                    serverChannel?.write(ByteBuffer.wrap(data)) ?: 0
                } catch (_: Exception) {
                    0
                }
                if (written > 0) clientNextSeq += written
                if (written < data.size) {
                    pendingToServer[i] = data.copyOfRange(written, data.size)
                    sendAck()
                    return
                }
                i++
            }
            pendingToServer.clear()
            sendAck()
        }

        private fun writeToServer(data: ByteArray): Int = try {
            serverChannel?.write(ByteBuffer.wrap(data)) ?: 0
        } catch (_: Exception) {
            0
        }

        private fun sendAck() {
            val tcp = buildTcpPacket(serverIp, clientIp, serverPort, clientPort,
                ourNextSeq, clientNextSeq, FLAG_ACK, 65535, ByteArray(0), ByteArray(0))
            enqueue(buildIpPacket(serverIp, clientIp, PROTO_TCP, tcp))
        }

        fun sendRst() {
            try {
                val tcp = buildTcpPacket(serverIp, clientIp, serverPort, clientPort,
                    ourNextSeq, clientNextSeq, FLAG_RST or FLAG_ACK, 0, ByteArray(0), ByteArray(0))
                enqueue(buildIpPacket(serverIp, clientIp, PROTO_TCP, tcp))
            } catch (_: Exception) {}
        }

        private fun sendFin() {
            sendToClient(ByteArray(0), FLAG_FIN or FLAG_ACK, ByteArray(0))
        }

        fun hardClose() {
            closed = true
            try { serverChannel?.close() } catch (_: Exception) {}
        }

        private fun cleanup() {
            hardClose()
            tcpFlows.remove(key)
        }
    }

    // ── Construcción de paquetes ───────────────────────────────────────────

    private fun buildIpPacket(srcIp: Int, dstIp: Int, protocol: Int, payload: ByteArray): ByteArray {
        val total = 20 + payload.size
        val out = ByteArray(total)
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, total)
        put16(out, 4, 0)                    // id
        put16(out, 6, 0x4000)               // Don't Fragment
        out[8] = 64                         // TTL
        out[9] = protocol.toByte()
        put16(out, 10, 0)                   // checksum luego
        put32(out, 12, srcIp.toLong() and 0xFFFFFFFFL)
        put32(out, 16, dstIp.toLong() and 0xFFFFFFFFL)
        var sum = 0L
        var i = 0
        while (i < 20) {
            sum += ((out[i].toLong() and 0xFF) shl 8) or (out[i + 1].toLong() and 0xFF)
            i += 2
        }
        while (sum ushr 16 != 0L) sum = (sum and 0xFFFFL) + (sum ushr 16)
        put16(out, 10, (sum.inv().toInt()) and 0xFFFF)
        System.arraycopy(payload, 0, out, 20, payload.size)
        return out
    }

    private fun buildUdpPacket(srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray {
        val out = ByteArray(8 + payload.size)
        put16(out, 0, srcPort)
        put16(out, 2, dstPort)
        put16(out, 4, out.size)
        put16(out, 6, 0)                    // checksum 0 = sin checksum (válido en IPv4)
        System.arraycopy(payload, 0, out, 8, payload.size)
        return out
    }

    /** Paquete TCP con checksum sobre pseudo-header IPv4. */
    private fun buildTcpPacket(
        srcIp: Int, dstIp: Int, srcPort: Int, dstPort: Int, seq: Long, ack: Long,
        flags: Int, window: Int, options: ByteArray, payload: ByteArray
    ): ByteArray {
        val optLen = (options.size + 3) and (3.inv())
        val headerLen = 20 + optLen
        val out = ByteArray(headerLen + payload.size)
        put16(out, 0, srcPort)
        put16(out, 2, dstPort)
        put32(out, 4, seq and 0xFFFFFFFFL)
        put32(out, 8, ack and 0xFFFFFFFFL)
        out[12] = ((headerLen / 4) shl 4).toByte()
        out[13] = flags.toByte()
        put16(out, 14, window)
        put16(out, 16, 0)                   // checksum luego
        put16(out, 18, 0)                   // puntero urgente
        System.arraycopy(options, 0, out, 20, options.size)
        System.arraycopy(payload, 0, out, headerLen, payload.size)

        var sum = 0L
        sum += ((srcIp ushr 16) and 0xFFFF).toLong() + (srcIp and 0xFFFF).toLong()
        sum += ((dstIp ushr 16) and 0xFFFF).toLong() + (dstIp and 0xFFFF).toLong()
        sum += PROTO_TCP.toLong() + out.size.toLong()
        var i = 0
        while (i < out.size) {
            val hi = out[i].toLong() and 0xFF
            val lo = if (i + 1 < out.size) out[i + 1].toLong() and 0xFF else 0L
            sum += (hi shl 8) or lo
            i += 2
        }
        while (sum ushr 16 != 0L) sum = (sum and 0xFFFFL) + (sum ushr 16)
        put16(out, 16, (sum.inv().toInt()) and 0xFFFF)
        return out
    }

    companion object {
        const val PROTO_TCP = 6
        const val PROTO_UDP = 17

        const val FLAG_FIN = 1
        const val FLAG_SYN = 2
        const val FLAG_RST = 4
        const val FLAG_PSH = 8
        const val FLAG_ACK = 16

        fun u16(b: ByteArray, off: Int): Int =
            ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)

        fun u32(b: ByteArray, off: Int): Int =
            ((b[off].toInt() and 0xFF) shl 24) or ((b[off + 1].toInt() and 0xFF) shl 16) or
                    ((b[off + 2].toInt() and 0xFF) shl 8) or (b[off + 3].toInt() and 0xFF)

        fun ipToInt(addr: InetAddress): Int {
            val a = addr.address
            return ((a[0].toInt() and 0xFF) shl 24) or ((a[1].toInt() and 0xFF) shl 16) or
                    ((a[2].toInt() and 0xFF) shl 8) or (a[3].toInt() and 0xFF)
        }

        fun intToIp(ip: Int): InetAddress = InetAddress.getByAddress(
            byteArrayOf(
                ((ip ushr 24) and 0xFF).toByte(), ((ip ushr 16) and 0xFF).toByte(),
                ((ip ushr 8) and 0xFF).toByte(), (ip and 0xFF).toByte()
            )
        )

        fun put16(b: ByteArray, off: Int, v: Int) {
            b[off] = ((v ushr 8) and 0xFF).toByte()
            b[off + 1] = (v and 0xFF).toByte()
        }

        fun put32(b: ByteArray, off: Int, v: Long) {
            b[off] = ((v ushr 24) and 0xFF).toByte()
            b[off + 1] = ((v ushr 16) and 0xFF).toByte()
            b[off + 2] = ((v ushr 8) and 0xFF).toByte()
            b[off + 3] = (v and 0xFF).toByte()
        }
    }
}
