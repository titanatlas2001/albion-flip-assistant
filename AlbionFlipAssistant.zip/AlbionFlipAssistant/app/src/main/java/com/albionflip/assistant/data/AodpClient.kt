package com.albionflip.assistant.data

import com.albionflip.assistant.albion.GameCodes
import com.albionflip.assistant.albion.MarketOrder
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Cliente de la API pública del Albion Online Data Project.
 * Servidor Américas: https://west.albion-online-data.com
 *
 * Endpoint usado: /api/v2/stats/prices/{items}.json?locations=...&qualities=...
 * Devuelve, por (item, ciudad, calidad): sell_price_min y buy_price_max entre otros.
 *
 * Los datos de AODP rellenan los mercados que aún no escaneaste en esta sesión;
 * tus capturas locales siempre tienen prioridad por ser más frescas.
 */
class AodpClient(private val server: String = SERVER_WEST) {

    data class PriceRow(
        val itemId: String,
        val city: String,          // nombre AODP (p. ej. "Caerleon", "Black Market")
        val quality: Int,
        val sellPriceMin: Long,
        val buyPriceMax: Long
    )

    /**
     * Consulta precios de los items indicados en las ciudades indicadas.
     * Devuelve filas de precio; lista vacía si falla (sin lanzar excepciones).
     */
    fun fetchPrices(items: List<String>, cities: List<String>, qualities: List<Int>): List<PriceRow> {
        if (items.isEmpty() || cities.isEmpty()) return emptyList()
        return try {
            val itemsParam = URLEncoder.encode(items.joinToString(","), "UTF-8")
            val locationsParam = URLEncoder.encode(cities.joinToString(","), "UTF-8")
            val qualitiesParam = URLEncoder.encode(qualities.distinct().joinToString(","), "UTF-8")
            val url = "https://$server/api/v2/stats/prices/$itemsParam.json" +
                    "?locations=$locationsParam&qualities=$qualitiesParam"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 12000
            conn.setRequestProperty("User-Agent", "AlbionFlipAssistant/1.0")
            try {
                if (conn.responseCode != 200) return emptyList()
                val body = conn.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
                parse(body)
            } finally {
                conn.disconnect()
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parse(body: String): List<PriceRow> {
        val arr = JSONArray(body)
        val out = ArrayList<PriceRow>(arr.length())
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            val city = j.optString("city", "").trim()
            val item = j.optString("item_id", "").trim()
            if (city.isEmpty() || item.isEmpty()) continue
            out.add(
                PriceRow(
                    itemId = item,
                    city = city,
                    quality = j.optInt("quality", 1).coerceIn(1, 5),
                    sellPriceMin = j.optLong("sell_price_min", 0L),
                    buyPriceMax = j.optLong("buy_price_max", 0L)
                )
            )
        }
        return out
    }

    /**
     * Convierte filas AODP en órdenes sintéticas y las inyecta en el bus
     * (solo rellena huecos: las capturas locales tienen prioridad).
     */
    fun ingest(rows: List<PriceRow>) {
        val now = System.currentTimeMillis()
        val orders = ArrayList<MarketOrder>(rows.size * 2)
        for (r in rows) {
            val loc = aodpCityToLocation(r.city) ?: continue
            if (r.sellPriceMin > 0) {
                orders.add(
                    MarketOrder(0, r.itemId, loc, r.quality, enchantOf(r.itemId),
                        r.sellPriceMin, 0, "offer", now)
                )
            }
            if (r.buyPriceMax > 0) {
                orders.add(
                    MarketOrder(0, r.itemId, loc, r.quality, enchantOf(r.itemId),
                        r.buyPriceMax, 0, "request", now)
                )
            }
        }
        CaptureBus.onOrders(orders, CaptureBus.SOURCE_AODP)
    }

    companion object {
        const val SERVER_WEST = "west.albion-online-data.com"      // Américas
        const val SERVER_EAST = "east.albion-online-data.com"      // Asia
        const val SERVER_EUROPE = "europe.albion-online-data.com"  // Europa

        /** Mapea nombres de ciudad AODP → ubicación interna de la app. */
        fun aodpCityToLocation(city: String): String? = when (city) {
            "Thetford" -> "0007"
            "Lymhurst" -> "1002"
            "Bridgewatch" -> "2004"
            "Martlock" -> "3008"
            "Fort Sterling" -> "4002"
            "Caerleon" -> "3005"
            "Brecilien" -> "5003"
            "Black Market" -> "BLACKBANK-"
            else -> null
        }

        fun enchantOf(itemId: String): Int {
            val at = itemId.indexOf('@')
            return if (at >= 0) itemId.substring(at + 1).toIntOrNull() ?: 0 else 0
        }
    }
}
