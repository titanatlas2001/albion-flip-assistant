package com.albionflip.assistant.albion

import org.json.JSONObject

/**
 * Una orden de mercado capturada (puerto de lib.MarketOrder de albiondata-client).
 * Cada orden llega como un string JSON dentro de la respuesta del juego.
 */
data class MarketOrder(
    val id: Long,
    val itemId: String,          // p. ej. "T6_BAG@2"
    val locationId: String,      // normalizada: "3005", "BLACKBANK-...", "@ISLAND@..."
    val quality: Int,            // 1..5
    val enchantment: Int,        // 0..3
    val unitPrice: Long,         // plata
    val amount: Int,
    val auctionType: String,     // "offer" (venta) | "request" (compra)
    val timestamp: Long = System.currentTimeMillis()
) {
    /** Clave de libro: item + calidad (las rutas comparan por item y calidad). */
    val bookKey: String get() = "${itemId}#$quality"

    companion object {
        /**
         * Parsea el JSON de una orden. Devuelve null si no es una orden válida.
         * Nota del protocolo (verificado en albiondata-client):
         *  - El Mercado Negro y las guaridas traen LocationId en el JSON.
         *  - Las ciudades originales traen LocationId nulo → usa la ubicación del jugador.
         */
        fun fromJson(text: String, fallbackLocation: String): MarketOrder? {
            return try {
                val j = JSONObject(text)
                val itemId = j.optString("ItemTypeId", "").trim()
                if (itemId.isEmpty()) return null
                var loc = j.optString("LocationId", "").trim()
                if (loc.isEmpty() || loc == "null") loc = fallbackLocation
                val normalized = GameCodes.normalizeLocation(loc) ?: fallbackLocation
                val ench = j.optInt("EnchantmentLevel", 0)
                MarketOrder(
                    id = j.optLong("Id", 0L),
                    itemId = itemId,
                    locationId = normalized,
                    quality = j.optInt("QualityLevel", 1).coerceIn(1, 5),
                    enchantment = ench,
                    unitPrice = j.optLong("UnitPriceSilver", 0L),
                    amount = j.optInt("Amount", 0),
                    auctionType = if (j.optString("AuctionType", "offer") == "request") "request" else "offer"
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}
