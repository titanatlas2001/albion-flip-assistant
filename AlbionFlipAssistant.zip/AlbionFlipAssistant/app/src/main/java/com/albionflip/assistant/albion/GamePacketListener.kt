package com.albionflip.assistant.albion

import com.albionflip.assistant.data.CaptureBus
import com.albionflip.assistant.photon.PhotonParser

/**
 * Escucha los mensajes decodificados del protocolo de Albion Online y
 * extrae: órdenes de mercado (subasta), ubicación actual (op Join) y
 * avisos de cifrado. Puerto del manejo de operations.go / op_join.go
 * de albiondata-client.
 */
class GamePacketListener {

    val parser = PhotonParser()

    init {
        parser.onResponse = { opCode, _, _, params ->
            handleResponse(opCode, params)
        }
        parser.onEncrypted = {
            // El servidor cifró los datos (misma limitación que el cliente oficial):
            // se informa en la UI, no hay clave disponible para decodificar.
            CaptureBus.onEncrypted()
        }
    }

    private fun handleResponse(opCode: Int, params: MutableMap<Byte, Any?>) {
        // 1) Respuesta de Join: param 8 = ubicación actual del jugador
        if (opCode == GameCodes.OP_JOIN) {
            (params[8] as? String)?.let { raw ->
                GameCodes.normalizeLocation(raw)?.let { loc ->
                    CaptureBus.onLocation(loc)
                }
            }
            return
        }

        // 2) Respuestas de subasta: órdenes de mercado.
        //    Órdenes actuales: 81 (offers) y 82 (requests). Se aceptan también los
        //    opcodes históricos (76/77) y cualquier respuesta cuya forma coincida
        //    (array de strings JSON con "ItemTypeId"), para sobrevivir a cambios
        //    de numeración del protocolo.
        val isAuctionOp = opCode == GameCodes.OP_AUCTION_GET_OFFERS ||
                opCode == GameCodes.OP_AUCTION_GET_REQUESTS ||
                opCode in GameCodes.LEGACY_AUCTION_OPS
        if (!isAuctionOp) return

        val rawOrders = params[0] as? Array<*> ?: return
        if (rawOrders.isEmpty()) return

        val fallbackLoc = CaptureBus.currentLocation.value
        val orders = ArrayList<MarketOrder>(rawOrders.size)
        for (element in rawOrders) {
            val text = element as? String ?: continue
            if (!text.contains("ItemTypeId")) continue
            MarketOrder.fromJson(text, fallbackLoc)?.let { orders.add(it) }
        }
        if (orders.isNotEmpty()) {
            CaptureBus.onOrders(orders, CaptureBus.SOURCE_LOCAL)
        }
    }
}
