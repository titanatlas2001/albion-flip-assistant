package com.albionflip.assistant.photon

/**
 * Buffer de lectura con primitivas little-endian para Protocol18.
 */
class Buf(private val data: ByteArray, private var pos: Int = 0, private val end: Int = data.size) {

    fun hasRemaining(): Boolean = pos < end

    fun remaining(): Int = end - pos

    fun readByte(): Byte {
        if (pos >= end) throw EOFException()
        return data[pos++]
    }

    fun readShortLE(): Short {
        if (end - pos < 2) throw EOFException()
        val v = ((data[pos].toInt() and 0xFF) or ((data[pos + 1].toInt() and 0xFF) shl 8)).toShort()
        pos += 2
        return v
    }

    fun readIntLE(): Int {
        if (end - pos < 4) throw EOFException()
        var v = 0
        for (i in 3 downTo 0) {
            v = (v shl 8) or (data[pos + i].toInt() and 0xFF)
        }
        pos += 4
        return v
    }

    fun readLongLE(): Long {
        if (end - pos < 8) throw EOFException()
        var v = 0L
        for (i in 7 downTo 0) {
            v = (v shl 8) or (data[pos + i].toLong() and 0xFF)
        }
        pos += 8
        return v
    }

    fun readBytes(n: Int): ByteArray {
        if (n < 0 || end - pos < n) throw EOFException()
        val out = data.copyOfRange(pos, pos + n)
        pos += n
        return out
    }

    class EOFException : Exception("Fin de buffer inesperado en Protocol18")
}

/** Envuelve bytes en un Buf con manejo defensivo de errores. */
fun wrapBuf(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): Buf? =
    try {
        if (length < 0 || offset + length > data.size) null else Buf(data, offset, offset + length)
    } catch (_: Exception) {
        null
    }
