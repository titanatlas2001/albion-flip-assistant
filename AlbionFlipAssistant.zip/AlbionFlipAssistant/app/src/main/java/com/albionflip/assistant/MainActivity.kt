package com.albionflip.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startForegroundService
import com.albionflip.assistant.capture.VpnCaptureService
import com.albionflip.assistant.ui.HistoryTab
import com.albionflip.assistant.ui.LiveTab
import com.albionflip.assistant.ui.SettingsTab
import com.albionflip.assistant.ui.theme.AlbionFlipTheme

class MainActivity : ComponentActivity() {

    private var pendingVpnStart = false

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && pendingVpnStart) {
                launchCaptureService()
            }
            pendingVpnStart = false
        }

    private val notifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            AlbionFlipTheme {
                MainScreen(
                    onStartCapture = { requestVpnAndStart() },
                    onStopCapture = { stopCaptureService() }
                )
            }
        }
    }

    private fun requestVpnAndStart() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            pendingVpnStart = true
            vpnPermissionLauncher.launch(prepare)
        } else {
            launchCaptureService()
        }
    }

    private fun launchCaptureService() {
        val intent = Intent(this, VpnCaptureService::class.java)
        intent.action = VpnCaptureService.ACTION_START
        startForegroundService(this, intent)
    }

    private fun stopCaptureService() {
        val intent = Intent(this, VpnCaptureService::class.java)
        intent.action = VpnCaptureService.ACTION_STOP
        startService(intent)
    }
}

private data class TabDef(val label: String, val icon: ImageVector)

@Composable
fun MainScreen(onStartCapture: () -> Unit, onStopCapture: () -> Unit) {
    var selected by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        TabDef("En vivo", Icons.Filled.Insights),
        TabDef("Historial", Icons.Filled.History),
        TabDef("Ajustes", Icons.Filled.Settings)
    )

    Scaffold(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, tab ->
                    NavigationBarItem(
                        selected = selected == i,
                        onClick = { selected = i },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        val mod = Modifier.padding(padding)
        when (selected) {
            0 -> LiveTab(modifier = mod, onStartCapture = onStartCapture, onStopCapture = onStopCapture)
            1 -> HistoryTab(modifier = mod)
            2 -> SettingsTab(modifier = mod)
        }
    }
}
