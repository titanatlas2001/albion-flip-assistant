package com.albionflip.assistant.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.albionflip.assistant.FlipApp
import com.albionflip.assistant.data.CaptureBus
import com.albionflip.assistant.data.FlipDb
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Historial básico: alertas generadas y sesiones de escaneo.
 */
@Composable
fun HistoryTab(modifier: Modifier = Modifier) {
    val app = LocalContext.current.applicationContext as FlipApp
    var subTab by remember { mutableIntStateOf(0) }
    var alerts by remember { mutableStateOf(listOf<FlipDb.AlertRow>()) }
    var scans by remember { mutableStateOf(listOf<FlipDb.ScanRow>()) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(reload) {
        alerts = app.db.recentAlerts()
        scans = app.db.recentScans()
    }

    Column(modifier = modifier.fillMaxSize().padding(12.dp)) {
        TabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Alertas") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Escaneos") })
        }
        Spacer(Modifier.height(8.dp))
        Row {
            OutlinedButton(onClick = { reload++ }) { Text("Actualizar") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = {
                app.db.clearHistory()
                reload++
            }) { Text("Borrar historial") }
        }
        Spacer(Modifier.height(8.dp))
        val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault())
        if (subTab == 0) {
            if (alerts.isEmpty()) {
                EmptyCard("Aún no se registraron alertas. Aparecen cuando una oferta supera tus umbrales.")
            } else {
                LazyColumn(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)) {
                    items(alerts) { a ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text(
                                    "${a.itemId}  Q${a.quality}",
                                    fontWeight = FontWeight.Bold, fontSize = 13.sp
                                )
                                Text(
                                    "${routeLabel(a.route)}: ${CaptureBus.displayName(a.fromLoc)} → ${CaptureBus.displayName(a.toLoc)} · " +
                                            "compra ${formatSilver(a.buy)} → vende ${formatSilver(a.sell)} · " +
                                            "+${formatSilver(a.profit)} (${"%.1f".format(a.margin)}%)",
                                    fontSize = 12.sp, color = Color(0xFF9AA4AD)
                                )
                                Text(fmt.format(Date(a.ts)), fontSize = 11.sp, color = Color(0xFF6E7880))
                            }
                        }
                    }
                }
            }
        } else {
            if (scans.isEmpty()) {
                EmptyCard("Aún no hay escaneos. Cada mercado que abras con la captura activa queda registrado aquí.")
            } else {
                LazyColumn(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)) {
                    items(scans) { s ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(Modifier.padding(10.dp).fillMaxWidth()) {
                                Column(Modifier.weight(1f)) {
                                    Text(CaptureBus.displayName(s.location), fontSize = 13.sp)
                                    Text(fmt.format(Date(s.ts)), fontSize = 11.sp, color = Color(0xFF6E7880))
                                }
                                Text("${s.orders} órdenes", fontSize = 12.sp, color = Color(0xFF9AA4AD))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyCard(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(text, Modifier.padding(14.dp), fontSize = 13.sp, color = Color(0xFF9AA4AD))
    }
}

internal fun routeLabel(route: String): String = when (route) {
    "BM" -> "M. Negro"
    "CAE" -> "Caerleon"
    "ENC" -> "Encant."
    else -> route
}
