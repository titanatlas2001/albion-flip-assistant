package com.albionflip.assistant.flips

import com.albionflip.assistant.data.AodpClient
import com.albionflip.assistant.data.CaptureBus
import com.albionflip.assistant.ui.ItemNames

/**
 * Una oportunidad de flippin calculada.
 */
data class FlipOpportunity(
    val route: String,          // ROUTE_BM | ROUTE_CAERLEON | ROUTE_ENCHANT
    val itemId: String,         // p. ej. "T6_BAG@2"
    val quality: Int,
    val fromLoc: String,        // dónde compras
    val toLoc: String,          // dónde vendes
    val buyPrice: Long,         // orden de venta más barata en fromLoc
    val sellPrice: Long,        // orden de compra que más paga en toLoc
    val profit: Long,           // tras impuestos
    val marginPct: Double,      // profit / buyPrice * 100
    val buySource: String,      // SOURCE_LOCAL | SOURCE_AODP
    val sellSource: String
) {
    /** Supera los umbrales configurados (se evalúa al crear la oportunidad). */
    val isAlert: Boolean get() = profit >= 0 && marginPct >= 0

    val displayName: String
        get() = ItemNames.nameFor(itemId) ?: itemId

    val tierLabel: String
        get() {
            val m = Regex("^T(\\d)").find(itemId) ?: return ""
            val tier = m.groupValues[1]
            val ench = AodpClient.enchantOf(itemId)
            return if (ench > 0) "T$tier.$ench" else "T$tier"
        }

    companion object {
        const val ROUTE_BM = "BM"
        const val ROUTE_CAERLEON = "CAE"
        const val ROUTE_ENCHANT = "ENC"
    }
}

/**
 * Motor de flippin: compara los libros de órdenes capturados (locales + AODP)
 * y produce la lista de oportunidades ordenada por ganancia.
 *
 * Rutas:
 *  - Mercado Negro (ROUTE_BM): comprar la orden de venta más barata entre las
 *    ciudades de origen activas y venderla a la orden de compra del Mercado Negro
 *    que más paga (mismo item y misma calidad; el encantamiento va dentro del
 *    itemId). Se aplica el impuesto de venta al vender contra la orden de compra.
 *  - Caerleon (ROUTE_CAERLEON): ida (ciudad → Caerleon contra su orden de compra)
 *    y vuelta (comprar en Caerleon → vender contra orden de compra de la ciudad).
 *  - Encantamientos (ROUTE_ENCHANT): si está activa, los items con encantamiento
 *    >= 1 se etiquetan con esta ruta; si está desactivada, se excluyen los items
 *    encantados del resultado.
 *
 * Las oportunidades ya vienen filtradas por los umbrales (ganancia mínima y
 * margen mínimo) — una oportunidad en la lista SIEMPRE es una oferta válida.
 */
object FlipEngine {

    fun compute(bus: CaptureBus, s: FlipSettings): List<FlipOpportunity> {
        val out = ArrayList<FlipOpportunity>()
        val cities = s.sourceCities
        if (cities.isEmpty()) return out

        val bmLocations = bus.locationsWithPrefix("BLACKBANK")
        val caerleon = "3005"

        // Claves candidatas: todo item#calidad visto en ciudades, M. Negro o Caerleon.
        val keys = HashSet<String>()
        keys.addAll(bus.knownKeys(cities))
        keys.addAll(bus.knownKeys(bmLocations))
        keys.addAll(bus.knownKeys(listOf(caerleon)))

        for (key in keys) {
            val itemId = key.substringBeforeLast('#')
            val quality = key.substringAfterLast('#').toIntOrNull() ?: 1
            val enchant = AodpClient.enchantOf(itemId)
            if (enchant > 0 && !s.routeEnchant) continue   // encantados excluidos

            // ── Ruta Mercado Negro ─────────────────────────────────────────
            if (s.routeBM && bmLocations.isNotEmpty()) {
                var bmBuy: Long? = null
                for (bm in bmLocations) {
                    val v = bus.bestBuy(bm, key)?.unitPrice ?: continue
                    if (bmBuy == null || v > bmBuy) bmBuy = v
                }
                if (bmBuy != null && bmBuy > 0) {
                    val sellNet = (bmBuy * (100.0 - s.salesTaxPct) / 100.0).toLong()
                    for (city in cities) {
                        val sell = bus.bestSell(city, key) ?: continue
                        if (sell.unitPrice <= 0) continue
                        val profit = sellNet - sell.unitPrice
                        if (profit < s.minProfit) continue
                        val margin = profit * 100.0 / sell.unitPrice
                        if (margin < s.minMarginPct) continue
                        out.add(
                            FlipOpportunity(
                                route = if (enchant > 0) FlipOpportunity.ROUTE_ENCHANT else FlipOpportunity.ROUTE_BM,
                                itemId = itemId, quality = quality,
                                fromLoc = city, toLoc = "BLACKBANK-",
                                buyPrice = sell.unitPrice, sellPrice = bmBuy,
                                profit = profit, marginPct = margin,
                                buySource = sell.takeIf { it.timestamp > 0 }?.let { CaptureBus.SOURCE_LOCAL }
                                    ?: CaptureBus.SOURCE_AODP,
                                sellSource = CaptureBus.SOURCE_LOCAL
                            )
                        )
                    }
                }
            }

            // ── Ruta Caerleon (ida y vuelta) ───────────────────────────────
            if (s.routeCaerleon) {
                val caeBuy = bus.bestBuy(caerleon, key)
                val caeSell = bus.bestSell(caerleon, key)

                // Ida: comprar en ciudad → vender contra orden de compra de Caerleon
                if (caeBuy != null && caeBuy.unitPrice > 0) {
                    val sellNet = (caeBuy.unitPrice * (100.0 - s.salesTaxPct) / 100.0).toLong()
                    for (city in cities) {
                        if (city == caerleon) continue
                        val sell = bus.bestSell(city, key) ?: continue
                        if (sell.unitPrice <= 0) continue
                        val profit = sellNet - sell.unitPrice
                        if (profit < s.minProfit) continue
                        val margin = profit * 100.0 / sell.unitPrice
                        if (margin < s.minMarginPct) continue
                        out.add(
                            FlipOpportunity(
                                route = if (enchant > 0) FlipOpportunity.ROUTE_ENCHANT else FlipOpportunity.ROUTE_CAERLEON,
                                itemId = itemId, quality = quality,
                                fromLoc = city, toLoc = caerleon,
                                buyPrice = sell.unitPrice, sellPrice = caeBuy.unitPrice,
                                profit = profit, marginPct = margin,
                                buySource = CaptureBus.SOURCE_LOCAL,
                                sellSource = CaptureBus.SOURCE_LOCAL
                            )
                        )
                    }
                }

                // Vuelta: comprar en Caerleon → vender contra orden de compra de la ciudad
                if (caeSell != null && caeSell.unitPrice > 0) {
                    for (city in cities) {
                        if (city == caerleon) continue
                        val cityBuy = bus.bestBuy(city, key) ?: continue
                        if (cityBuy.unitPrice <= 0) continue
                        val sellNet = (cityBuy.unitPrice * (100.0 - s.salesTaxPct - s.setupFeePct) / 100.0).toLong()
                        val profit = sellNet - caeSell.unitPrice
                        if (profit < s.minProfit) continue
                        val margin = profit * 100.0 / caeSell.unitPrice
                        if (margin < s.minMarginPct) continue
                        out.add(
                            FlipOpportunity(
                                route = if (enchant > 0) FlipOpportunity.ROUTE_ENCHANT else FlipOpportunity.ROUTE_CAERLEON,
                                itemId = itemId, quality = quality,
                                fromLoc = caerleon, toLoc = city,
                                buyPrice = caeSell.unitPrice, sellPrice = cityBuy.unitPrice,
                                profit = profit, marginPct = margin,
                                buySource = CaptureBus.SOURCE_LOCAL,
                                sellSource = CaptureBus.SOURCE_LOCAL
                            )
                        )
                    }
                }
            }
        }

        return out.sortedByDescending { it.profit }.take(200)
    }
}
