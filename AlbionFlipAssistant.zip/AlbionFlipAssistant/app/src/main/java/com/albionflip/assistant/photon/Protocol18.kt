package com.albionflip.assistant.photon

/**
 * Decodificador Protocol18 de Photon — puerto fiel de
 * ao-data/albiondata-client (client/photon/deserializer.go),
 * que a su vez es un puerto del Protocol18Deserializer en C# de AlbionDataAvalonia.
 *
 * Todos los enteros/floats del payload de Protocol18 son LITTLE-ENDIAN.
 * Las longitudes de colecciones y strings usan varint comprimido (7 bits, LEB128).
 * Los enteros comprimidos usan zigzag.
 */
object Protocol18 {

    // Códigos de tipo de Protocol18
    const val TYPE_UNKNOWN = 0
    const val TYPE_BOOLEAN = 2
    const val TYPE_BYTE = 3
    const val TYPE_SHORT = 4
    const val TYPE_FLOAT = 5
    const val TYPE_DOUBLE = 6
    const val TYPE_STRING = 7
    const val TYPE_NULL = 8
    const val TYPE_COMPRESSED_INT = 9
    const val TYPE_COMPRESSED_LONG = 10
    const val TYPE_INT1 = 11          // entero sin signo de 1 byte
    const val TYPE_INT1_NEG = 12      // entero sin signo de 1 byte, negado
    const val TYPE_INT2 = 13          // entero sin signo de 2 bytes
    const val TYPE_INT2_NEG = 14
    const val TYPE_LONG1 = 15
    const val TYPE_LONG1_NEG = 16
    const val TYPE_LONG2 = 17
    const val TYPE_LONG2_NEG = 18
    const val TYPE_CUSTOM = 19
    const val TYPE_DICTIONARY = 20
    const val TYPE_HASHTABLE = 21
    const val TYPE_OBJECT_ARRAY = 23
    const val TYPE_OPERATION_REQUEST = 24
    const val TYPE_OPERATION_RESPONSE = 25
    const val TYPE_EVENT_DATA = 26
    const val TYPE_BOOL_FALSE = 27
    const val TYPE_BOOL_TRUE = 28
    const val TYPE_SHORT_ZERO = 29
    const val TYPE_INT_ZERO = 30
    const val TYPE_LONG_ZERO = 31
    const val TYPE_FLOAT_ZERO = 32
    const val TYPE_DOUBLE_ZERO = 33
    const val TYPE_BYTE_ZERO = 34
    const val TYPE_ARRAY = 0x40       // array "desnudo"; 0x40|tipoElem = array tipado
    const val CUSTOM_TYPE_SLIM_BASE = 0x80

    /**
     * Lee una tabla de parámetros: varint(cantidad) | (clave:Byte tipo:Byte valor)*
     * Devuelve un mapa clave (Byte) → valor decodificado.
     */
    fun readParameterTable(buf: Buf): MutableMap<Byte, Any?> {
        val count = readCount(buf).toInt()
        val params = HashMap<Byte, Any?>(count)
        var i = 0
        while (i < count && buf.hasRemaining()) {
            val key = buf.readByte()
            val tc = buf.readByte()
            params[key] = deserialize(buf, tc)
            i++
        }
        return params
    }

    /** Decodifica un valor según su código de tipo. */
    fun deserialize(buf: Buf, tc: Byte): Any? {
        val t = tc.toInt() and 0xFF
        if (t >= CUSTOM_TYPE_SLIM_BASE) {
            return deserializeCustom(buf, t.toByte())
        }
        return when (t) {
            TYPE_UNKNOWN, TYPE_NULL -> null
            TYPE_BOOLEAN -> buf.readByte() != 0.toByte()
            TYPE_BYTE -> buf.readByte()
            TYPE_SHORT -> readInt16(buf)
            TYPE_FLOAT -> readFloat32(buf)
            TYPE_DOUBLE -> readFloat64(buf)
            TYPE_STRING -> readString(buf)
            TYPE_COMPRESSED_INT -> readCompressedInt32(buf)
            TYPE_COMPRESSED_LONG -> readCompressedInt64(buf)
            TYPE_INT1 -> buf.readByte().toInt() and 0xFF
            TYPE_INT1_NEG -> -(buf.readByte().toInt() and 0xFF)
            TYPE_INT2 -> readUint16(buf).toInt()
            TYPE_INT2_NEG -> -(readUint16(buf).toInt())
            TYPE_LONG1 -> buf.readByte().toLong() and 0xFF
            TYPE_LONG1_NEG -> -((buf.readByte().toLong()) and 0xFF)
            TYPE_LONG2 -> readUint16(buf).toLong()
            TYPE_LONG2_NEG -> -(readUint16(buf).toLong())
            TYPE_CUSTOM -> deserializeCustom(buf, 0)
            TYPE_DICTIONARY -> deserializeDictionary(buf)
            TYPE_HASHTABLE -> deserializeDictionary(buf)
            TYPE_OBJECT_ARRAY -> deserializeObjectArray(buf)
            TYPE_OPERATION_REQUEST -> deserializeOperationRequestInner(buf)
            TYPE_OPERATION_RESPONSE -> deserializeOperationResponseInner(buf)
            TYPE_EVENT_DATA -> deserializeEventDataInner(buf)
            TYPE_BOOL_FALSE -> false
            TYPE_BOOL_TRUE -> true
            TYPE_SHORT_ZERO -> 0.toShort()
            TYPE_INT_ZERO -> 0
            TYPE_LONG_ZERO -> 0L
            TYPE_FLOAT_ZERO -> 0.0f
            TYPE_DOUBLE_ZERO -> 0.0
            TYPE_BYTE_ZERO -> 0.toByte()
            TYPE_ARRAY -> deserializeNestedArray(buf)
            else ->
                if (t and TYPE_ARRAY == TYPE_ARRAY) {
                    deserializeTypedArray(buf, (t and TYPE_ARRAY.inv()).toByte())
                } else {
                    "ERROR - unknown type 0x%02X".format(t)
                }
        }
    }

    /** Array tipado: todos los elementos comparten tipo. varint(cant) | elemento* */
    private fun deserializeTypedArray(buf: Buf, elemType: Byte): Any {
        val size = readCount(buf).toInt()
        return when (elemType.toInt() and 0xFF) {
            TYPE_BOOLEAN -> {
                val packedBytes = (size + 7) / 8
                val packed = buf.readBytes(packedBytes)
                BooleanArray(size) { i ->
                    (packed[i / 8].toInt() and (1 shl (i % 8))) != 0
                }
            }
            TYPE_BYTE -> buf.readBytes(size)
            TYPE_SHORT -> ShortArray(size) { readInt16(buf) }
            TYPE_FLOAT -> FloatArray(size) { readFloat32(buf) }
            TYPE_DOUBLE -> DoubleArray(size) { readFloat64(buf) }
            TYPE_STRING -> Array(size) { readString(buf) }
            TYPE_CUSTOM -> {
                val customTypeId = buf.readByte()
                Array(size) { deserializeCustomPayload(buf, customTypeId, false) }
            }
            TYPE_DICTIONARY -> Array(size) { deserializeDictionary(buf) }
            TYPE_HASHTABLE -> Array(size) { deserializeDictionary(buf) }
            TYPE_COMPRESSED_INT -> IntArray(size) { readCompressedInt32(buf) }
            TYPE_COMPRESSED_LONG -> LongArray(size) { readCompressedInt64(buf) }
            else -> Array<Any?>(size) { deserialize(buf, elemType) }
        }
    }

    /** Array desnudo (0x40): varint(cant) | tipoElem | elemento* */
    private fun deserializeNestedArray(buf: Buf): Any? {
        val size = readCount(buf).toInt()
        if (!buf.hasRemaining()) return null
        val tc = buf.readByte()
        return Array<Any?>(size) { deserialize(buf, tc) }
    }

    /** Array de objetos: varint(cant) | (tipoElem | valor)* */
    private fun deserializeObjectArray(buf: Buf): Array<Any?> {
        val size = readCount(buf).toInt()
        val out = arrayOfNulls<Any?>(size)
        for (i in 0 until size) {
            if (!buf.hasRemaining()) break
            val tc = buf.readByte()
            out[i] = deserialize(buf, tc)
        }
        return out
    }

    /** Diccionario: tipoClave | tipoValor | varint(cant) | (clave | valor)*. Tipo 0 = tipo propio por entrada. */
    private fun deserializeDictionary(buf: Buf): HashMap<Any?, Any?> {
        val keyTc = buf.readByte()
        val valTc = buf.readByte()
        val count = readCount(buf).toInt()
        val out = HashMap<Any?, Any?>(count)
        for (i in 0 until count) {
            if (!buf.hasRemaining()) break
            val kt = if (keyTc.toInt() == 0) buf.readByte() else keyTc
            val vt = if (valTc.toInt() == 0) buf.readByte() else valTc
            val key = deserialize(buf, kt)
            val value = deserialize(buf, vt)
            out[keyKey(key)] = value
        }
        return out
    }

    /** Las claves pueden ser Byte/String/Int; las normalizamos a String para consulta uniforme. */
    private fun keyKey(key: Any?): Any? = key

    private fun deserializeCustom(buf: Buf, gpType: Byte): Any? {
        val isSlim = gpType.toInt() and 0xFF >= CUSTOM_TYPE_SLIM_BASE
        val customId = if (isSlim) ((gpType.toInt() and 0x7F).toByte()) else buf.readByte()
        return deserializeCustomPayload(buf, customId, isSlim)
    }

    private fun deserializeCustomPayload(buf: Buf, customId: Byte, isSlim: Boolean): Any? {
        val size = readCount(buf).toInt()
        if (size < 0 || size > buf.remaining()) {
            if (isSlim) {
                return mapOf("type" to customId, "data" to buf.readBytes(buf.remaining()))
            }
            return null
        }
        return mapOf("type" to customId, "data" to buf.readBytes(size))
    }

    private fun deserializeOperationRequestInner(buf: Buf): Map<String, Any?> {
        val opCode = buf.readByte()
        val params = readParameterTable(buf)
        return mapOf("operationCode" to opCode, "parameters" to params)
    }

    private fun deserializeOperationResponseInner(buf: Buf): Map<String, Any?>? {
        if (buf.remaining() < 3) return null
        val opCode = buf.readByte()
        val returnCode = readInt16(buf)
        var debugMsg = ""
        if (buf.hasRemaining()) {
            val tc = buf.readByte()
            val v = deserialize(buf, tc)
            if (v is String) debugMsg = v
        }
        val params = readParameterTable(buf)
        return mapOf(
            "operationCode" to opCode,
            "returnCode" to returnCode,
            "debugMessage" to debugMsg,
            "parameters" to params
        )
    }

    private fun deserializeEventDataInner(buf: Buf): Map<String, Any?> {
        val code = buf.readByte()
        val params = readParameterTable(buf)
        return mapOf("code" to code, "parameters" to params)
    }

    // ── Lectores de bajo nivel ─────────────────────────────────────────────

    fun readInt16(buf: Buf): Short = buf.readShortLE()

    fun readUint16(buf: Buf): Int = buf.readShortLE().toInt() and 0xFFFF

    private fun readFloat32(buf: Buf): Float = Float.fromBits(buf.readIntLE())

    private fun readFloat64(buf: Buf): Double = Double.fromBits(buf.readLongLE())

    /** String Protocol18: varint(longitud) | bytes UTF-8 */
    fun readString(buf: Buf): String {
        val length = readCompressedUint32(buf).toInt()
        if (length <= 0 || length > buf.remaining()) return ""
        return String(buf.readBytes(length), Charsets.UTF_8)
    }

    /** Longitud de colección/array (varint comprimido). */
    fun readCount(buf: Buf): Long = readCompressedUint32(buf)

    fun readCompressedUint32(buf: Buf): Long {
        var value = 0L
        var shift = 0
        while (true) {
            if (!buf.hasRemaining()) return 0
            val b = buf.readByte().toInt() and 0xFF
            value = value or ((b and 0x7F).toLong() shl shift)
            if (b and 0x80 == 0) return value
            shift += 7
            if (shift >= 35) return 0
        }
    }

    private fun readCompressedUint64(buf: Buf): Long {
        var value = 0L
        var shift = 0
        while (true) {
            if (!buf.hasRemaining()) return 0
            val b = buf.readByte().toInt() and 0xFF
            value = value or ((b and 0x7F).toLong() shl shift)
            if (b and 0x80 == 0) return value
            shift += 7
            if (shift >= 70) return 0
        }
    }

    fun readCompressedInt32(buf: Buf): Int {
        val v = readCompressedUint32(buf)
        return ((v ushr 1) xor -(v and 1)).toInt()
    }

    fun readCompressedInt64(buf: Buf): Long {
        val v = readCompressedUint64(buf)
        return (v ushr 1) xor -(v and 1)
    }
}
