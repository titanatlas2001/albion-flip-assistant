package com.albionflip.assistant.data

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.albionflip.assistant.MainActivity
import com.albionflip.assistant.R
import com.albionflip.assistant.albion.GameCodes
import com.albionflip.assistant.flips.FlipOpportunity

/**
 * Genera notificaciones cuando aparece una oferta nueva que supera los umbrales.
 * Deduplica por (ruta + item + calidad) dentro de una ventana de tiempo.
 */
class AlertManager(private val context: Context) {

    private val recent = HashMap<String, Long>()
    private val notifyManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val CHANNEL_FLIPS = "flips"
        private const val DEDUP_WINDOW_MS = 5 * 60 * 1000L
        private const val MAX_NOTIFICATIONS_PER_BATCH = 3
    }

    fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_FLIPS,
            context.getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.notif_channel_desc)
        }
        notifyManager.createNotificationChannel(channel)
    }

    /** Se llama tras cada recálculo de oportunidades. */
    fun onFlips(flips: List<FlipOpportunity>) {
        val now = System.currentTimeMillis()
        // limpia deduplicación expirada
        recent.entries.removeIf { now - it.value > DEDUP_WINDOW_MS }

        var sent = 0
        synchronized(recent) {
            for (f in flips) {
                if (sent >= MAX_NOTIFICATIONS_PER_BATCH) break
                if (!f.isAlert) continue
                val key = "${f.route}#${f.itemId}#${f.quality}"
                val last = recent[key]
                if (last != null && now - last < DEDUP_WINDOW_MS) continue
                recent[key] = now
                notify(f)
                sent++
            }
        }
    }

    private fun notify(f: FlipOpportunity) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val title = when (f.route) {
            FlipOpportunity.ROUTE_BM -> "Oferta Mercado Negro: ${f.displayName}"
            FlipOpportunity.ROUTE_CAERLEON -> "Oferta Caerleon: ${f.displayName}"
            FlipOpportunity.ROUTE_ENCHANT -> "Oferta Encantamiento: ${f.displayName}"
            else -> "Oferta: ${f.displayName}"
        }
        val text = "Compra ${CaptureBus.displayName(f.fromLoc)} → vende ${CaptureBus.displayName(f.toLoc)} · " +
                "Ganancia ${formatSilver(f.profit)} (${"%.1f".format(f.marginPct)}%)"

        val intent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(context, CHANNEL_FLIPS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(intent)
            .build()
        try {
            notifyManager.notify((f.itemId + f.route).hashCode(), notification)
        } catch (_: Exception) {
            // sin permiso o canal cerrado: se ignora silenciosamente
        }
    }

    private fun formatSilver(v: Long): String = when {
        v >= 1_000_000 -> "%.2fM".format(v / 1_000_000.0)
        v >= 10_000 -> "%.1fk".format(v / 1_000.0)
        else -> v.toString()
    }
}
