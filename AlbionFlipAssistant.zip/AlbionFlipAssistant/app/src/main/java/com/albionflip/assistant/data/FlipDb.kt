package com.albionflip.assistant.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Almacenamiento local: historial básico de escaneos y alertas generadas.
 */
class FlipDb(context: Context) : SQLiteOpenHelper(context, "flip_assistant.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                location TEXT NOT NULL,
                orders INTEGER NOT NULL
            )"""
        )
        db.execSQL(
            """CREATE TABLE alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                route TEXT NOT NULL,
                item_id TEXT NOT NULL,
                quality INTEGER NOT NULL,
                from_loc TEXT NOT NULL,
                to_loc TEXT NOT NULL,
                buy_price INTEGER NOT NULL,
                sell_price INTEGER NOT NULL,
                profit INTEGER NOT NULL,
                margin REAL NOT NULL
            )"""
        )
        db.execSQL("CREATE INDEX idx_alerts_ts ON alerts(ts)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS scans")
        db.execSQL("DROP TABLE IF EXISTS alerts")
        onCreate(db)
    }

    fun insertScan(ts: Long, location: String, orders: Int) {
        val cv = ContentValues().apply {
            put("ts", ts); put("location", location); put("orders", orders)
        }
        writableDatabase.insert("scans", null, cv)
        // recorte ligero del historial
        writableDatabase.execSQL("DELETE FROM scans WHERE id NOT IN (SELECT id FROM scans ORDER BY id DESC LIMIT 500)")
    }

    fun insertAlert(ts: Long, route: String, itemId: String, quality: Int,
                    fromLoc: String, toLoc: String, buy: Long, sell: Long, profit: Long, margin: Double) {
        val cv = ContentValues().apply {
            put("ts", ts); put("route", route); put("item_id", itemId); put("quality", quality)
            put("from_loc", fromLoc); put("to_loc", toLoc)
            put("buy_price", buy); put("sell_price", sell)
            put("profit", profit); put("margin", margin)
        }
        writableDatabase.insert("alerts", null, cv)
        writableDatabase.execSQL("DELETE FROM alerts WHERE id NOT IN (SELECT id FROM alerts ORDER BY id DESC LIMIT 1000)")
    }

    data class AlertRow(
        val ts: Long, val route: String, val itemId: String, val quality: Int,
        val fromLoc: String, val toLoc: String, val buy: Long, val sell: Long,
        val profit: Long, val margin: Double
    )

    fun recentAlerts(limit: Int = 100): List<AlertRow> {
        val out = ArrayList<AlertRow>()
        readableDatabase.rawQuery(
            "SELECT ts, route, item_id, quality, from_loc, to_loc, buy_price, sell_price, profit, margin FROM alerts ORDER BY ts DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    AlertRow(
                        c.getLong(0), c.getString(1), c.getString(2), c.getInt(3),
                        c.getString(4), c.getString(5), c.getLong(6), c.getLong(7),
                        c.getLong(8), c.getDouble(9)
                    )
                )
            }
        }
        return out
    }

    data class ScanRow(val ts: Long, val location: String, val orders: Int)

    fun recentScans(limit: Int = 100): List<ScanRow> {
        val out = ArrayList<ScanRow>()
        readableDatabase.rawQuery(
            "SELECT ts, location, orders FROM scans ORDER BY ts DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out.add(ScanRow(c.getLong(0), c.getString(1), c.getInt(2)))
            }
        }
        return out
    }

    fun clearHistory() {
        writableDatabase.execSQL("DELETE FROM scans")
        writableDatabase.execSQL("DELETE FROM alerts")
    }
}
