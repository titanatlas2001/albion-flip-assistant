package com.albionflip.assistant.capture

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.albionflip.assistant.MainActivity
import com.albionflip.assistant.R
import com.albionflip.assistant.albion.GamePacketListener
import com.albionflip.assistant.data.AlertManager
import com.albionflip.assistant.data.CaptureBus
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Servicio VPN de captura pasiva.
 *
 * Establece una VPN local (sin root) por la que pasa el tráfico del teléfono,
 * reenvía TODO el tráfico intacto (el juego funciona con normalidad) y alimenta
 * el decodificador Photon con los payloads UDP.
 */
class VpnCaptureService : VpnService() {

    private var router: PacketRouter? = null
    private val listener = GamePacketListener()

    companion object {
        const val ACTION_START = "com.albionflip.assistant.START"
        const val ACTION_STOP = "com.albionflip.assistant.STOP"
        const val NOTIF_ID = 42
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundWithNotification()
        startCapture()
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val intent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, AlertManager.CHANNEL_FLIPS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(getString(R.string.notif_service_title))
            .setContentText(getString(R.string.notif_service_text))
            .setOngoing(true)
            .setContentIntent(intent)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIF_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    /**
     * VPN local: enruta todo el tráfico IPv4 por el dispositivo TUN.
     * El router reenvía todo intacto; el juego funciona con normalidad.
     */
    private fun establishTun(): ParcelFileDescriptor? {
        return Builder()
            .setSession("Albion Flip Assistant")
            .setMtu(16384)
            .addAddress("10.111.222.3", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("8.8.4.4")
            .establish()
    }

    private fun startCapture() {
        if (router != null) return   // ya capturando
        val tun = establishTun() ?: run {
            CaptureBus.onError("No se pudo establecer la VPN local (¿permiso revocado?)")
            stopSelf()
            return
        }

        val router = PacketRouter(
            tunIn = FileInputStream(tun.fileDescriptor),
            tunOut = FileOutputStream(tun.fileDescriptor),
            vpn = this,
            onUdpPayload = { payload ->
                CaptureBus.onPacket()
                listener.parser.receivePacket(payload)
            },
            onError = { msg -> CaptureBus.onError(msg) }
        )
        this.router = router
        router.start()
        CaptureBus.setVpnRunning(true)
    }

    private fun stopCapture() {
        router?.stop()
        router = null
        CaptureBus.setVpnRunning(false)
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    override fun onRevoke() {
        // El usuario (u otra VPN) retiró el permiso
        stopCapture()
        stopSelf()
        super.onRevoke()
    }
}
