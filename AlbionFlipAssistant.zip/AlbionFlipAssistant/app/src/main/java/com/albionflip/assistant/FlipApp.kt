package com.albionflip.assistant

import android.app.Application
import com.albionflip.assistant.data.AlertManager
import com.albionflip.assistant.data.AodpClient
import com.albionflip.assistant.data.CaptureBus
import com.albionflip.assistant.data.FlipDb
import com.albionflip.assistant.flips.FlipSettings
import com.albionflip.assistant.ui.ItemNames
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Punto de arranque: canal de notificaciones, base de datos, ajustes y bus compartido.
 */
class FlipApp : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    lateinit var settings: FlipSettings
        private set
    lateinit var db: FlipDb
        private set
    lateinit var alerts: AlertManager
        private set

    override fun onCreate() {
        super.onCreate()
        ItemNames.load(this)
        alerts = AlertManager(this)
        alerts.createChannel()
        settings = FlipSettings(this)
        db = FlipDb(this)
        CaptureBus.start(appScope, settings, db)
        CaptureBus.alertManager = alerts
        CaptureBus.aodp = AodpClient(settings.aodpServer)
    }
}
