package com.albionflip.assistant.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.albionflip.assistant.FlipApp
import com.albionflip.assistant.data.AodpClient

/**
 * Ajustes: rutas, umbrales, impuestos, ciudades de origen y AODP.
 * Los cambios se guardan al instante y afectan el siguiente recálculo.
 */
@Composable
fun SettingsTab(modifier: Modifier = Modifier) {
    val app = LocalContext.current.applicationContext as FlipApp
    val s = app.settings
    var revision by remember { mutableIntStateOf(0) }   // fuerza recomposición al cambiar ajustes
    fun bump() { revision++ }

    Column(modifier = modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {

        // ── Rutas ──────────────────────────────────────────────────────────
        SectionCard("Rutas de flippin") {
            SwitchRow("Mercado Negro (ciudad → M. Negro)", s.routeBM) { s.routeBM = it; bump() }
            SwitchRow("Caerleon (ida y vuelta)", s.routeCaerleon) { s.routeCaerleon = it; bump() }
            SwitchRow("Encantamientos (items con encant. 1-3)", s.routeEnchant) { s.routeEnchant = it; bump() }
        }

        // ── Umbrales ───────────────────────────────────────────────────────
        SectionCard("Umbrales de oferta") {
            LongField(
                label = "Ganancia mínima (plata)",
                value = s.minProfit,
                onCommit = { v -> s.minProfit = v; bump() }
            )
            DoubleField(
                label = "Margen mínimo (%)",
                value = s.minMarginPct,
                onCommit = { v -> s.minMarginPct = v; bump() }
            )
            Text(
                "Una oferta aparece en la lista (y dispara alerta) solo si gana al menos esa plata Y ese margen.",
                fontSize = 12.sp, color = Color(0xFF9AA4AD)
            )
        }

        // ── Impuestos ──────────────────────────────────────────────────────
        SectionCard("Impuestos y tasas") {
            DoubleField(
                label = "Impuesto de venta (%)",
                value = s.salesTaxPct,
                onCommit = { v -> s.salesTaxPct = v; bump() }
            )
            DoubleField(
                label = "Tasa de publicación (%)",
                value = s.setupFeePct,
                onCommit = { v -> s.setupFeePct = v; bump() }
            )
            Text(
                "Verifica los valores vigentes del juego tras cada parche; por defecto 3% venta y 2,5% publicación.",
                fontSize = 12.sp, color = Color(0xFF9AA4AD)
            )
        }

        // ── Ciudades de origen ─────────────────────────────────────────────
        SectionCard("Ciudades donde comprar") {
            SwitchRow("Thetford", s.cityThetford) { s.cityThetford = it; bump() }
            SwitchRow("Lymhurst", s.cityLymhurst) { s.cityLymhurst = it; bump() }
            SwitchRow("Bridgewatch", s.cityBridgewatch) { s.cityBridgewatch = it; bump() }
            SwitchRow("Martlock", s.cityMartlock) { s.cityMartlock = it; bump() }
            SwitchRow("Fort Sterling", s.cityFortSterling) { s.cityFortSterling = it; bump() }
            SwitchRow("Brecilien", s.cityBrecilien) { s.cityBrecilien = it; bump() }
            SwitchRow("Caerleon como origen", s.cityCaerleonAsSource) { s.cityCaerleonAsSource = it; bump() }
        }

        // ── AODP ───────────────────────────────────────────────────────────
        SectionCard("Datos comunitarios (AODP)") {
            SwitchRow("Usar AODP para rellenar mercados no escaneados", s.aodpEnabled) {
                s.aodpEnabled = it; bump()
            }
            Text("Servidor", fontSize = 12.sp, color = Color(0xFF9AA4AD))
            Spacer(Modifier.height(4.dp))
            Row {
                FilterChip(
                    selected = s.aodpServer == AodpClient.SERVER_WEST,
                    onClick = { s.aodpServer = AodpClient.SERVER_WEST; bump() },
                    label = { Text("Américas") }
                )
                Spacer(Modifier.width(6.dp))
                FilterChip(
                    selected = s.aodpServer == AodpClient.SERVER_EUROPE,
                    onClick = { s.aodpServer = AodpClient.SERVER_EUROPE; bump() },
                    label = { Text("Europa") }
                )
                Spacer(Modifier.width(6.dp))
                FilterChip(
                    selected = s.aodpServer == AodpClient.SERVER_EAST,
                    onClick = { s.aodpServer = AodpClient.SERVER_EAST; bump() },
                    label = { Text("Asia") }
                )
            }
            Text(
                "Américas (west) es tu servidor. Los datos de AODP son agregados de otros jugadores: útiles como referencia, menos frescos que tus escaneos.",
                fontSize = 12.sp, color = Color(0xFF9AA4AD)
            )
        }

        // ── Notificaciones ─────────────────────────────────────────────────
        SectionCard("Alertas") {
            SwitchRow("Notificar ofertas nuevas", s.notificationsEnabled) {
                s.notificationsEnabled = it; bump()
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "Cómo funciona: la app escucha (sin modificar nada) el tráfico del juego en tu teléfono. " +
                    "Cada mercado que abres en Albion alimenta el análisis; las oportunidades se recalculan " +
                    "al momento y las que superan tus umbrales generan alerta. La compra la haces tú en el juego.",
            fontSize = 12.sp, color = Color(0xFF6E7880)
        )
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
    HorizontalDivider(color = Color(0xFF2A323A), thickness = 0.5.dp)
}

@Composable
private fun LongField(label: String, value: Long, onCommit: (Long) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it.filter { c -> c.isDigit() } },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        trailingIcon = {
            androidx.compose.material3.TextButton(onClick = {
                val v = text.toLongOrNull()
                if (v != null) onCommit(v)
            }) { Text("Guardar") }
        }
    )
}

@Composable
private fun DoubleField(label: String, value: Double, onCommit: (Double) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        trailingIcon = {
            androidx.compose.material3.TextButton(onClick = {
                val v = text.replace(',', '.').toDoubleOrNull()
                if (v != null) onCommit(v)
            }) { Text("Guardar") }
        }
    )
}
