package com.albionflip.assistant.albion

/**
 * Códigos de operación del protocolo de Albion Online (verificados contra
 * ao-data/albiondata-client, rama master, enum OperationType 2025-2026)
 * y mapeo de ubicaciones contra Triky313/AlbionOnline-StatisticsAnalysis.
 */
object GameCodes {

    // Operaciones de interés (valores actuales del enum del cliente de referencia)
    const val OP_JOIN = 2                       // respuesta con la ubicación actual (param 8)
    const val OP_AUCTION_GET_OFFERS = 81        // órdenes de venta (offers)
    const val OP_AUCTION_GET_REQUESTS = 82      // órdenes de compra (requests)

    // Valores históricos (protocolos anteriores): se aceptan por robustez,
    // siempre validando la forma de los datos (array de strings JSON).
    val LEGACY_AUCTION_OPS = setOf(76, 77)

    /** Normaliza el string de ubicación recibido del juego (puerto de normalizeLocationID). */
    fun normalizeLocation(raw: String): String? {
        val s = raw.trim(',', '.', ' ')
        if (s.isEmpty()) return null
        // Isla de jugador: @island@<uuid> → @ISLAND@<uuid>
        val island = Regex("(?i)@island@[0-9a-f-]{36}").find(s)?.value
        if (island != null) return "@ISLAND@" + island.substring(8)
        if (Regex("^[0-9]{3,6}$").matches(s)) return s
        val ls = s.lowercase()
        if (ls.startsWith("island-player-") ||
            ls.startsWith("@player-island") ||
            ls.startsWith("@island-") ||
            s.startsWith("BLACKBANK-") ||
            s.endsWith("-HellDen") ||
            s.endsWith("-Auction2")
        ) return s
        return null
    }

    /** Nombre legible de una ubicación del juego (IDs verificados en la comunidad). */
    fun locationName(loc: String): String = when {
        loc.startsWith("BLACKBANK-") -> "Mercado Negro"
        loc.contains("SMUGGLER") -> "Guarida de contrabandistas"
        else -> when (loc) {
            "0007" -> "Thetford"
            "1002" -> "Lymhurst"
            "2004" -> "Bridgewatch"
            "3008" -> "Martlock"
            "4002" -> "Fort Sterling"
            "5003" -> "Brecilien"
            "3005" -> "Caerleon"
            "0301" -> "Portal de Thetford"
            "1301" -> "Portal de Lymhurst"
            "2301" -> "Portal de Bridgewatch"
            "3301" -> "Portal de Martlock"
            "4301" -> "Portal de Fort Sterling"
            "0004" -> "Swamp Cross"
            "1006" -> "Forest Cross"
            "2002" -> "Steppe Cross"
            "3002" -> "Highland Cross"
            "4006" -> "Mountain Cross"
            else -> if (loc.endsWith("-Auction2")) "Subasta secundaria"
            else if (loc.endsWith("-HellDen")) "Infierno ($loc)"
            else loc
        }
    }

    /** ¿La ubicación es una de las ciudades con mercado (incluye Caerleon y Brecilien)? */
    val CITY_LOCATIONS = mapOf(
        "0007" to "Thetford",
        "1002" to "Lymhurst",
        "2004" to "Bridgewatch",
        "3008" to "Martlock",
        "4002" to "Fort Sterling",
        "5003" to "Brecilien",
        "3005" to "Caerleon"
    )

    /** Ciudades para AODP (nombres de la API, servidor Américas = west). */
    val AODP_CITY_NAMES = listOf(
        "Thetford", "Lymhurst", "Bridgewatch", "Martlock", "Fort Sterling", "Caerleon", "Brecilien"
    )
}
