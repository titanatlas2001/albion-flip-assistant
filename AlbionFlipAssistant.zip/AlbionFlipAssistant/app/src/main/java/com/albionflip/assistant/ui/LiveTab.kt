package com.albionflip.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.albionflip.assistant.data.AodpClient
import com.albionflip.assistant.data.CaptureBus
import com.albionflip.assistant.flips.FlipOpportunity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Panel en vivo: estado de la captura y lista de oportunidades de flippin,
 * ordenada por ganancia. Las oportunidades ya vienen filtradas por umbrales.
 */
@Composable
fun LiveTab(modifier: Modifier = Modifier, onStartCapture: () -> Unit, onStopCapture: () -> Unit) {
    val vpnRunning by CaptureBus.vpnRunning.collectAsState()
    val packets by CaptureBus.packetsSeen.collectAsState()
    val orders by CaptureBus.ordersCaptured.collectAsState()
    val location by CaptureBus.currentLocation.collectAsState()
    val encrypted by CaptureBus.encryptedDetected.collectAsState()
    val lastScan by CaptureBus.lastScanAt.collectAsState()
    val lastError by CaptureBus.lastError.collectAsState()
    val aodpRefreshing by CaptureBus.aodpRefreshing.collectAsState()
    val flips by CaptureBus.liveFlips.collectAsState()

    var routeFilter by remember { mutableStateOf("ALL") }
    var refreshKey by remember { mutableIntStateOf(0) }

    val app = androidx.compose.ui.platform.LocalContext.current.applicationContext as com.albionflip.assistant.FlipApp
    val settings = app.settings

    Column(modifier = modifier.fillMaxSize().padding(12.dp)) {

        // ── Estado de la captura ───────────────────────────────────────────
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { if (vpnRunning) onStopCapture() else onStartCapture() },
                        colors = if (vpnRunning)
                            androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        else androidx.compose.material3.ButtonDefaults.buttonColors()
                    ) {
                        Text(if (vpnRunning) "Detener captura" else "Iniciar captura")
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            if (vpnRunning) "Capturando tráfico…" else "Captura apagada",
                            fontWeight = FontWeight.Bold,
                            color = if (vpnRunning) Color(0xFF7FD1AE) else Color(0xFFC3CAD1)
                        )
                        Text(
                            if (vpnRunning) "Abre los mercados en el juego para escanearlos"
                            else "Actívala y juega; el tráfico pasa intacto",
                            fontSize = 12.sp,
                            color = Color(0xFF9AA4AD)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Ubicación actual: ${if (location.isEmpty()) "— (cambia de zona en el juego)" else CaptureBus.displayName(location)}",
                    fontSize = 13.sp
                )
                Text("Paquetes vistos: $packets · Órdenes capturadas: $orders", fontSize = 13.sp)
                if (lastScan > 0) {
                    Text(
                        "Último escaneo: " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(lastScan)),
                        fontSize = 12.sp, color = Color(0xFF9AA4AD)
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        if (encrypted) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2A20)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    "El servidor está cifrando los datos de mercado ahora mismo. " +
                            "Ningún cliente pasivo puede leerlos (igual que el cliente oficial). " +
                            "La captura continúa automáticamente cuando vuelvan en claro.",
                    Modifier.padding(10.dp), fontSize = 12.sp, color = Color(0xFFF0B27A)
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        lastError?.let { err ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2020)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    Modifier.padding(10.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(err, fontSize = 12.sp, color = Color(0xFFF08A7A), modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { CaptureBus.clearError() }) { Text("OK") }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // ── Filtros de ruta + AODP ─────────────────────────────────────────
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = routeFilter == "ALL",
                onClick = { routeFilter = "ALL" },
                label = { Text("Todas") }
            )
            FilterChip(
                selected = routeFilter == FlipOpportunity.ROUTE_BM,
                onClick = { routeFilter = FlipOpportunity.ROUTE_BM },
                label = { Text("M. Negro") }
            )
            FilterChip(
                selected = routeFilter == FlipOpportunity.ROUTE_CAERLEON,
                onClick = { routeFilter = FlipOpportunity.ROUTE_CAERLEON },
                label = { Text("Caerleon") }
            )
            FilterChip(
                selected = routeFilter == FlipOpportunity.ROUTE_ENCHANT,
                onClick = { routeFilter = FlipOpportunity.ROUTE_ENCHANT },
                label = { Text("Encant.") }
            )
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(
                onClick = {
                    CaptureBus.refreshAodp(force = true)
                    refreshKey++
                },
                enabled = !aodpRefreshing
            ) {
                if (aodpRefreshing) {
                    CircularProgressIndicator(Modifier.height(16.dp).width(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Actualizar AODP")
            }
            Spacer(Modifier.width(8.dp))
            Text("${flips.size} ofertas", fontSize = 12.sp, color = Color(0xFF9AA4AD))
        }

        Spacer(Modifier.height(8.dp))

        // ── Lista de oportunidades ─────────────────────────────────────────
        val visible = if (routeFilter == "ALL") flips else flips.filter { it.route == routeFilter }
        if (visible.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Aún no hay ofertas", fontWeight = FontWeight.Bold)
                    Text(
                        "1) Inicia la captura.\n" +
                                "2) Juega y abre los mercados que quieras comparar " +
                                "(ciudad ↔ Mercado Negro, ciudad ↔ Caerleon).\n" +
                                "3) Ajusta la ganancia mínima en Ajustes si ves poco o mucho ruido.",
                        fontSize = 13.sp, color = Color(0xFF9AA4AD)
                    )
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(visible, key = { "${it.route}-${it.itemId}-${it.quality}-${it.fromLoc}" }) { f ->
                    FlipCard(f)
                }
            }
        }
    }
}

@Composable
private fun FlipCard(f: FlipOpportunity) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${f.displayName}  ${f.tierLabel}",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                    maxLines = 1
                )
                AssistChip(
                    onClick = {},
                    label = {
                        Text(
                            when (f.route) {
                                FlipOpportunity.ROUTE_BM -> "M. Negro"
                                FlipOpportunity.ROUTE_CAERLEON -> "Caerleon"
                                else -> "Encant."
                            },
                            fontSize = 11.sp
                        )
                    }
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Q$f · ${CaptureBus.displayName(f.fromLoc)} → ${CaptureBus.displayName(f.toLoc)}" +
                        if (f.buySource == CaptureBus.SOURCE_AODP) "  (AODP)" else "",
                fontSize = 12.sp, color = Color(0xFF9AA4AD)
            )
            Spacer(Modifier.height(6.dp))
            Row {
                Column(Modifier.weight(1f)) {
                    Text("Compras por", fontSize = 11.sp, color = Color(0xFF9AA4AD))
                    Text(formatSilver(f.buyPrice), fontWeight = FontWeight.SemiBold)
                }
                Column(Modifier.weight(1f)) {
                    Text("Vendes a", fontSize = 11.sp, color = Color(0xFF9AA4AD))
                    Text(formatSilver(f.sellPrice), fontWeight = FontWeight.SemiBold)
                }
                Column(Modifier.weight(1f)) {
                    Text("Ganancia", fontSize = 11.sp, color = Color(0xFF9AA4AD))
                    Text(
                        formatSilver(f.profit),
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7FD1AE)
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text("Margen", fontSize = 11.sp, color = Color(0xFF9AA4AD))
                    Text(
                        "${"%.1f".format(f.marginPct)}%",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE8B93E)
                    )
                }
            }
        }
    }
}

internal fun formatSilver(v: Long): String = when {
    v >= 1_000_000 -> "%.2fM".format(v / 1_000_000.0)
    v >= 10_000 -> "%.1fk".format(v / 1_000.0)
    else -> v.toString()
}
