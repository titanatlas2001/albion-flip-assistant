package com.albionflip.assistant.data

import com.albionflip.assistant.albion.GameCodes
import com.albionflip.assistant.albion.MarketOrder
import com.albionflip.assistant.flips.FlipEngine
import com.albionflip.assistant.flips.FlipOpportunity
import com.albionflip.assistant.flips.FlipSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Bus central de la app: estado en vivo compartido entre la captura (VPN),
 * el análisis de flippin y la UI.
 */
object CaptureBus {

    /** Mejor orden conocida por ubicación para cada clave item#calidad. */
    class Book {
        var bestSell: MarketOrder? = null   // offer más barata
        var bestBuy: MarketOrder? = null    // request que más paga
        var updatedAt: Long = 0
        var source: String = SOURCE_LOCAL   // SOURCE_LOCAL | SOURCE_AODP
    }

    // ubicación normalizada → (clave item#calidad → libro)
    private val books = ConcurrentHashMap<String, ConcurrentHashMap<String, Book>>()

    private val _vpnRunning = MutableStateFlow(false)
    val vpnRunning: StateFlow<Boolean> = _vpnRunning

    private val _packetsSeen = MutableStateFlow(0L)
    val packetsSeen: StateFlow<Long> = _packetsSeen

    private val _ordersCaptured = MutableStateFlow(0L)
    val ordersCaptured: StateFlow<Long> = _ordersCaptured

    private val _currentLocation = MutableStateFlow("")
    val currentLocation: StateFlow<String> = _currentLocation

    private val _encryptedDetected = MutableStateFlow(false)
    val encryptedDetected: StateFlow<Boolean> = _encryptedDetected

    private val _lastScanAt = MutableStateFlow(0L)
    val lastScanAt: StateFlow<Long> = _lastScanAt

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError

    private val _aodpRefreshing = MutableStateFlow(false)
    val aodpRefreshing: StateFlow<Boolean> = _aodpRefreshing

    private var lastAodpRefresh = 0L

    private val _liveFlips = MutableStateFlow<List<FlipOpportunity>>(emptyList())
    val liveFlips: StateFlow<List<FlipOpportunity>> = _liveFlips

    var scope: CoroutineScope? = null
    var settings: FlipSettings? = null
    var db: FlipDb? = null
    var alertManager: AlertManager? = null
    var aodp: AodpClient? = null

    private val recomputeTrigger = MutableStateFlow(0L)

    /** Arranca el recomputo periódico/debounced de flips dentro del scope dado. */
    @OptIn(FlowPreview::class)
    fun start(appScope: CoroutineScope, appSettings: FlipSettings, database: FlipDb) {
        scope = appScope
        settings = appSettings
        db = database
        appScope.launch {
            recomputeTrigger.debounce(400).collect {
                recompute()
            }
        }
    }

    // ── Entradas de la captura ─────────────────────────────────────────────

    fun onPacket() {
        _packetsSeen.value = _packetsSeen.value + 1
    }

    fun onLocation(loc: String) {
        _currentLocation.value = loc
    }

    fun onEncrypted() {
        _encryptedDetected.value = true
    }

    fun onError(msg: String) {
        _lastError.value = msg
    }

    fun clearError() {
        _lastError.value = null
    }

    /**
     * Consulta AODP los items ya conocidos para rellenar los mercados que
     * aún no escaneaste en esta sesión. Las capturas locales siempre ganan.
     */
    fun refreshAodp(force: Boolean = false) {
        val s = settings ?: return
        val client = aodp ?: return
        if (!s.aodpEnabled) return
        val now = System.currentTimeMillis()
        if (!force && now - lastAodpRefresh < 60_000L) return
        if (_aodpRefreshing.value) return
        lastAodpRefresh = now

        scope?.launch {
            _aodpRefreshing.value = true
            try {
                val keys = HashSet<String>()
                keys.addAll(knownKeys(s.sourceCities))
                keys.addAll(knownKeys(locationsWithPrefix("BLACKBANK")))
                keys.addAll(knownKeys(listOf("3005")))
                val itemIds = keys.map { it.substringBeforeLast('#') }
                    .filter { it.startsWith("T") }
                    .distinct()
                    .take(600)
                if (itemIds.isEmpty()) return@launch

                val cities = ArrayList<String>(s.sourceCities.size + 2)
                for (c in s.sourceCities) {
                    GameCodes.CITY_LOCATIONS[c]?.let { cities.add(it) }
                }
                cities.add("Black Market")

                // AODP por calidad individual para no inflar la URL
                val qualities = listOf(1, 2, 3)
                var idx = 0
                while (idx < itemIds.size) {
                    val chunk = itemIds.subList(idx, minOf(idx + 100, itemIds.size))
                    for (q in qualities) {
                        val rows = client.fetchPrices(chunk, cities, listOf(q))
                        ingestRows(client, rows)
                    }
                    idx += 100
                }
                recomputeTrigger.value = System.currentTimeMillis()
            } catch (_: Exception) {
                onError("Fallo consultando AODP (¿sin conexión?)")
            } finally {
                _aodpRefreshing.value = false
            }
        }
    }

    private suspend fun ingestRows(client: AodpClient, rows: List<AodpClient.PriceRow>) =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            client.ingest(rows)
        }

    fun setVpnRunning(running: Boolean) {
        _vpnRunning.value = running
        if (!running) {
            // conservar los libros; solo cambia el estado
        }
    }

    /** Lote de órdenes decodificadas (desde paquetes del juego o de AODP). */
    fun onOrders(orders: List<MarketOrder>, source: String = SOURCE_LOCAL) {
        if (orders.isEmpty()) return
        var changed = false
        for (o in orders) {
            val map = books.getOrPut(o.locationId) { ConcurrentHashMap() }
            val book = map.getOrPut(o.bookKey) { Book() }
            synchronized(book) {
                // datos locales siempre ganan sobre AODP; AODP solo rellena huecos
                if (book.source != SOURCE_LOCAL || source == SOURCE_LOCAL) {
                    if (o.auctionType == "offer") {
                        val cur = book.bestSell
                        if (cur == null || o.unitPrice in 1 until cur.unitPrice) {
                            book.bestSell = o; changed = true
                        }
                    } else {
                        val cur = book.bestBuy
                        if (cur == null || o.unitPrice > cur.unitPrice) {
                            book.bestBuy = o; changed = true
                        }
                    }
                    book.updatedAt = o.timestamp
                    book.source = source
                }
            }
        }
        if (source == SOURCE_LOCAL) {
            _ordersCaptured.value = _ordersCaptured.value + orders.size
            _lastScanAt.value = System.currentTimeMillis()
            scope?.launch {
                db?.insertScan(System.currentTimeMillis(), orders.first().locationId, orders.size)
            }
        }
        if (changed) recomputeTrigger.value = System.currentTimeMillis()
    }

    // ── Consultas para el motor de flips ───────────────────────────────────

    fun bestSell(location: String, key: String): MarketOrder? {
        val map = books[location] ?: return null
        val b = map[key] ?: return null
        synchronized(b) { return b.bestSell?.copy() }
    }

    fun bestBuy(location: String, key: String): MarketOrder? {
        val map = books[location] ?: return null
        val b = map[key] ?: return null
        synchronized(b) { return b.bestBuy?.copy() }
    }

    /** Todas las claves item#calidad conocidas en las ubicaciones indicadas. */
    fun knownKeys(locations: Collection<String>): Set<String> {
        val out = HashSet<String>()
        for (loc in locations) {
            books[loc]?.let { out.addAll(it.keys) }
        }
        return out
    }

    /** Ubicaciones conocidas que empiezan por el prefijo dado (p. ej. BLACKBANK-). */
    fun locationsWithPrefix(prefix: String): List<String> =
        books.keys.filter { it.startsWith(prefix) }

    fun clearBooks() {
        books.clear()
        _liveFlips.value = emptyList()
    }

    /** Recalcula las oportunidades y lanza alertas si procede. */
    private fun recompute() {
        val s = settings ?: return
        val flips = FlipEngine.compute(this, s)
        _liveFlips.value = flips
        alertManager?.onFlips(flips)
    }

    companion object {
        const val SOURCE_LOCAL = "local"
        const val SOURCE_AODP = "aodp"

        /** Etiqueta legible de una ubicación para la UI. */
        fun displayName(loc: String): String = GameCodes.locationName(loc)
    }
}
