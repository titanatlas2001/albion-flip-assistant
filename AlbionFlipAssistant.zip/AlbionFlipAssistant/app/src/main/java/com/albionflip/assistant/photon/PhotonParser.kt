package com.albionflip.assistant.photon

/**
 * Parser del protocolo Photon de Albion Online — puerto fiel de
 * ao-data/albiondata-client (client/photon/parser.go), que a su vez
 * porta PhotonParser.cs de AlbionDataAvalonia.
 *
 * Todo multi-byte a nivel de paquete/comando es BIG-ENDIAN, salvo el
 * returnCode de las respuestas (LITTLE-ENDIAN) y los valores de Protocol18.
 *
 * Un datagrama UDP puede contener varios paquetes Photon encadenados
 * (coalescing): se delimitan comparando peerId/challenge.
 */
class PhotonParser {

    // Códigos de comando de Photon
    private val CMD_DISCONNECT = 4
    private val CMD_SEND_RELIABLE = 6
    private val CMD_SEND_UNRELIABLE = 7
    private val CMD_SEND_FRAGMENT = 8

    // Tipos de mensaje fiable
    private val MSG_REQUEST = 2
    private val MSG_RESPONSE = 3
    private val MSG_EVENT = 4
    private val MSG_RESPONSE_ALT = 7     // algunas builds envían OperationResponse como tipo 7
    private val MSG_ENCRYPTED = 131      // comando cifrado (p. ej. datos de mercado en algunas builds)

    // Flags del header del paquete
    private val FLAG_ENCRYPTED = 1
    private val FLAG_CRC_ENABLED = 0xCC

    private val PHOTON_HEADER_LENGTH = 12
    private val COMMAND_HEADER_LENGTH = 12
    private val FRAGMENT_HEADER_LENGTH = 20
    private val CRC_FIELD_LENGTH = 4

    private val MAX_PENDING_SEGMENTS = 64
    private val MAX_SEGMENT_TOTAL_LENGTH = 8 shl 20 // 8 MiB

    // Reensamblado de fragmentos, por número de secuencia inicial
    private class SegmentedPackage(val totalLength: Int) {
        var bytesWritten = 0
        val payload = ByteArray(totalLength)
    }

    private val pendingSegments = LinkedHashMap<Int, SegmentedPackage>()

    /** Callbacks: invocados desde el hilo de lectura de la VPN. */
    var onRequest: ((opCode: Int, params: MutableMap<Byte, Any?>) -> Unit)? = null
    var onResponse: ((opCode: Int, returnCode: Short, debugMessage: String, params: MutableMap<Byte, Any?>) -> Unit)? = null
    var onEvent: ((code: Int, params: MutableMap<Byte, Any?>) -> Unit)? = null
    var onEncrypted: (() -> Unit)? = null

    /**
     * Procesa el payload bruto de un datagrama UDP (uno o más paquetes Photon).
     * Devuelve true si todos los paquetes encontrados fueron válidos.
     */
    fun receivePacket(payload: ByteArray): Boolean {
        if (payload.size < PHOTON_HEADER_LENGTH) return false

        val (peerId, challenge) = packetIdentity(payload, 0) ?: return false
        val (firstLen, terminalEncrypted) = packetLength(payload, 0) ?: return false

        if (terminalEncrypted || firstLen == payload.size) {
            return receiveSinglePacket(payload, 0, payload.size)
        }

        val ranges = ArrayList<IntArray>()
        ranges.add(intArrayOf(0, firstLen))
        var off = firstLen
        var framingOk = true
        while (off < payload.size) {
            val id = packetIdentity(payload, off)
            if (id == null || id.first != peerId || id.second != challenge) {
                framingOk = false
                break
            }
            val len = packetLength(payload, off)
            if (len == null) {
                framingOk = false
                break
            }
            ranges.add(intArrayOf(off, len.first))
            off += len.first
            if (len.second) break
        }

        var success = framingOk
        for (r in ranges) {
            if (!receiveSinglePacket(payload, r[0], r[0] + r[1])) success = false
        }
        return success
    }

    /** Analiza exactamente un paquete Photon (header + comandos) en payload[from, to). */
    private fun receiveSinglePacket(payload: ByteArray, from: Int, to: Int): Boolean {
        if (to - from < PHOTON_HEADER_LENGTH) return false

        var offset = from + 2                     // salta peerId (2 bytes)
        val flags = payload[offset].toInt() and 0xFF   // Byte con signo: enmascarar (0xCC → 0xFFFFFFCC)
        offset++
        val commandCount = payload[offset].toInt() and 0xFF; offset++
        offset += 8                               // salta timestamp (4) + challenge (4)

        if (flags == FLAG_ENCRYPTED) {
            onEncrypted?.invoke()
            return false
        }

        if (flags == FLAG_CRC_ENABLED) {
            if (to - offset < CRC_FIELD_LENGTH) return false
            var crc = 0
            for (i in 0 until CRC_FIELD_LENGTH) {
                crc = (crc shl 8) or (payload[offset + i].toInt() and 0xFF)
            }
            offset += CRC_FIELD_LENGTH
            // CRC32 variante Photon: IEEE sin XOR final, campo CRC a cero antes de
            // calcular. Igual que la referencia Go: se calcula solo sobre los bytes
            // de ESTE paquete (no del datagrama completo si hay coalescing).
            val crcPayload = payload.copyOfRange(from, to)
            for (i in PHOTON_HEADER_LENGTH until PHOTON_HEADER_LENGTH + CRC_FIELD_LENGTH) {
                crcPayload[i] = 0
            }
            if (crc != calculateCrc(crcPayload).toInt()) return false
        }

        for (i in 0 until commandCount) {
            val result = handleCommand(payload, from, to, offset)
                ?: return false
            offset = result
        }
        return offset == to
    }

    private fun packetIdentity(payload: ByteArray, offset: Int): Pair<Int, Int>? {
        if (payload.size - offset < PHOTON_HEADER_LENGTH) return null
        val peerId = ((payload[offset].toInt() and 0xFF) shl 8) or (payload[offset + 1].toInt() and 0xFF)
        var challenge = 0
        for (i in 0 until 4) {
            challenge = (challenge shl 8) or (payload[offset + 8 + i].toInt() and 0xFF)
        }
        return peerId to challenge
    }

    /**
     * Calcula dónde termina el paquete que empieza en offset (header + comandos declarados),
     * sin decodificar el contenido de los comandos.
     * El segundo valor del par indica "paquete cifrado terminal" (longitud = resto del payload).
     */
    private fun packetLength(payload: ByteArray, offset: Int): Pair<Int, Boolean>? {
        if (payload.size - offset < PHOTON_HEADER_LENGTH) return null

        val flags = payload[offset + 2].toInt() and 0xFF   // enmascarar signo del Byte
        if (flags == FLAG_ENCRYPTED) return Pair(payload.size - offset, true)

        var headerLen = PHOTON_HEADER_LENGTH
        if (flags == FLAG_CRC_ENABLED) headerLen += CRC_FIELD_LENGTH
        if (payload.size - offset < headerLen) return null

        val commandCount = payload[offset + 3].toInt() and 0xFF
        if (commandCount == 0) return null

        var cmdOffset = offset + headerLen
        for (i in 0 until commandCount) {
            if (payload.size - cmdOffset < COMMAND_HEADER_LENGTH) return null
            val cmdLen = readUint32BE(payload, cmdOffset + 4)
            if (cmdLen < COMMAND_HEADER_LENGTH || payload.size - cmdOffset < cmdLen) return null
            cmdOffset += cmdLen
        }

        val length = cmdOffset - offset
        if (length < headerLen) return null
        return Pair(length, false)
    }

    /** CRC32 variante Photon (polinomio IEEE estándar, sin XOR final). */
    private fun calculateCrc(data: ByteArray): Long {
        val key = 3988292384L
        var result = 0xFFFFFFFFL
        for (b in data) {
            result = result xor (b.toLong() and 0xFF)
            for (j in 0 until 8) {
                result = if (result and 1L != 0L) {
                    (result ushr 1) xor key
                } else {
                    result ushr 1
                }
            }
        }
        return result
    }

    /** Procesa un comando en offset. Devuelve el nuevo offset, o null si el paquete es inválido. */
    private fun handleCommand(src: ByteArray, from: Int, to: Int, offsetIn: Int): Int? {
        var offset = offsetIn
        if (to - offset < COMMAND_HEADER_LENGTH) return null

        val cmdType = src[offset].toInt() and 0xFF
        offset++               // cmdType
        offset++               // channelId
        offset++               // commandFlags
        offset++               // reservado
        var cmdLen = readUint32BE(src, offset)
        offset += 4
        offset += 4            // reliableSequenceNumber
        cmdLen -= COMMAND_HEADER_LENGTH

        if (cmdLen < 0 || to - offset < cmdLen) return null

        when (cmdType) {
            CMD_DISCONNECT -> return offset + cmdLen

            CMD_SEND_UNRELIABLE -> {
                if (cmdLen < 4) return null
                handleSendReliable(src, offset + 4, cmdLen - 4)
                return offset + cmdLen
            }

            CMD_SEND_RELIABLE -> {
                handleSendReliable(src, offset, cmdLen)
                return offset + cmdLen
            }

            CMD_SEND_FRAGMENT -> {
                handleSendFragment(src, offset, cmdLen)
                return offset + cmdLen
            }

            else -> return offset + cmdLen
        }
    }

    private fun handleSendReliable(src: ByteArray, offsetIn: Int, cmdLen: Int) {
        if (cmdLen < 2 || cmdLen > src.size - offsetIn) return
        var offset = offsetIn + 1                    // salta signalByte
        val msgType = src[offset].toInt() and 0xFF
        offset++
        val dataLen = cmdLen - 2
        if (dataLen < 0 || src.size - offset < dataLen) return

        if (msgType == MSG_ENCRYPTED) {
            onEncrypted?.invoke()
            return
        }

        when (msgType) {
            MSG_REQUEST -> dispatchRequest(src, offset, dataLen)
            MSG_RESPONSE, MSG_RESPONSE_ALT -> dispatchResponse(src, offset, dataLen)
            MSG_EVENT -> dispatchEvent(src, offset, dataLen)
        }
    }

    private fun dispatchRequest(src: ByteArray, offset: Int, len: Int) {
        if (len < 1) return
        val opCode = src[offset].toInt() and 0xFF
        val params = readParameterTableSafe(src, offset + 1, len - 1)
        onRequest?.invoke(opCode, params)
    }

    private fun dispatchResponse(src: ByteArray, offset: Int, len: Int) {
        if (len < 3) return
        val opCode = src[offset].toInt() and 0xFF
        // returnCode es LittleEndian (única excepción)
        val returnCode = ((src[offset + 1].toInt() and 0xFF) or ((src[offset + 2].toInt() and 0xFF) shl 8)).toShort()

        // Tras el returnCode: 1 byte de tipo + valor (mensaje de depuración), luego la tabla de parámetros.
        // Caso especial Albion: si ese valor es un array de strings, son datos de mercado
        // (se exponen como params[0], igual que hace albiondata-client).
        val buf = Buf(src, offset + 3, offset + len)
        try {
            if (buf.hasRemaining()) {
                val tc = buf.readByte()
                // Protocol18.deserialize avanza el buffer; la tabla de parámetros
                // continúa justo después del mensaje de depuración.
                val value = try {
                    Protocol18.deserialize(buf, tc)
                } catch (_: Buf.EOFException) {
                    null
                }
                if (value is Array<*>) {
                    val strings = value.mapNotNull { it as? String }
                    if (strings.size == value.size) {
                        // Datos de mercado embebidos en la posición del mensaje de depuración
                        val params = HashMap<Byte, Any?>(1)
                        params[0] = strings.toTypedArray()
                        onResponse?.invoke(opCode, returnCode, "", params)
                        return
                    }
                }
            }
            val params = Protocol18.readParameterTable(buf)
            onResponse?.invoke(opCode, returnCode, "", params)
        } catch (_: Buf.EOFException) {
            // Mensaje truncado: se ignora de forma defensiva
        }
    }

    private fun dispatchEvent(src: ByteArray, offset: Int, len: Int) {
        if (len < 1) return
        val code = src[offset].toInt() and 0xFF
        val params = readParameterTableSafe(src, offset + 1, len - 1)
        onEvent?.invoke(code, params)
    }

    private fun readParameterTableSafe(src: ByteArray, offset: Int, len: Int): MutableMap<Byte, Any?> {
        return try {
            if (len <= 0) HashMap() else Protocol18.readParameterTable(Buf(src, offset, offset + len))
        } catch (_: Buf.EOFException) {
            HashMap()
        }
    }

    private fun handleSendFragment(src: ByteArray, offsetIn: Int, cmdLen: Int) {
        if (cmdLen < FRAGMENT_HEADER_LENGTH || src.size - offsetIn < FRAGMENT_HEADER_LENGTH) return

        var offset = offsetIn
        val startSeq = readUint32BE(src, offset); offset += 4
        offset += 4                // fragmentCount
        offset += 4                // fragmentNumber
        val totalLen = readUint32BE(src, offset); offset += 4
        val fragOffset = readUint32BE(src, offset); offset += 4
        val fragLen = cmdLen - FRAGMENT_HEADER_LENGTH

        if (fragLen < 0 || src.size - offset < fragLen) return

        var seg = pendingSegments[startSeq]
        if (seg == null) {
            if (totalLen <= 0 || totalLen > MAX_SEGMENT_TOTAL_LENGTH) {
                // totalLength corrupto u hostil: no asignar memoria
                return
            }
            if (pendingSegments.size >= MAX_PENDING_SEGMENTS) {
                evictOldestSegment()
            }
            seg = SegmentedPackage(totalLen)
            pendingSegments[startSeq] = seg
        }

        val end = fragOffset + fragLen
        if (end <= seg.payload.size) {
            System.arraycopy(src, offset, seg.payload, fragOffset, fragLen)
        }
        seg.bytesWritten += fragLen

        if (seg.bytesWritten >= seg.totalLength) {
            pendingSegments.remove(startSeq)
            handleSendReliable(seg.payload, 0, seg.payload.size)
        }
    }

    private fun evictOldestSegment() {
        val it = pendingSegments.entries.iterator()
        if (it.hasNext()) {
            it.next()
            it.remove()
        }
    }

    private fun readUint32BE(src: ByteArray, offset: Int): Int {
        var v = 0
        for (i in 0 until 4) {
            v = (v shl 8) or (src[offset + i].toInt() and 0xFF)
        }
        return v
    }
}
