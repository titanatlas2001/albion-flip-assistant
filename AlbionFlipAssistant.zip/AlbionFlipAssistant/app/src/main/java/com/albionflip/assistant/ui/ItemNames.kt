package com.albionflip.assistant.ui

import android.content.Context

/**
 * Nombres de objetos (inglés, el estándar de la comunidad de trading de Albion)
 * cargados desde assets/item_names.txt. Formato: <itemId>\t<Nombre>
 * Generado a partir de ao-bin-dumps (MIT, proyecto comunitario de datos del juego).
 * Si un item no está, la UI muestra el ID crudo (p. ej. T6_BAG@2).
 */
object ItemNames {

    private val names = HashMap<String, String>()
    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        try {
            context.assets.open("item_names.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val tab = line.indexOf('\t')
                    if (tab <= 0) continue
                    val id = line.substring(0, tab).trim()
                    val name = line.substring(tab + 1).trim()
                    if (id.isNotEmpty() && name.isNotEmpty()) names[id] = name
                }
            }
        } catch (_: Exception) {
            // asset ausente o corrupto: la app funciona con IDs crudos
        }
    }

    fun nameFor(itemId: String): String? {
        val direct = names[itemId]
        if (direct != null) return direct
        // T4_BAG@1 → nombre base del T4_BAG
        val at = itemId.indexOf('@')
        if (at > 0) return names[itemId.substring(0, at)]
        return null
    }
}
