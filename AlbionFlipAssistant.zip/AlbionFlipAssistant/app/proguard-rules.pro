# Reglas de ProGuard (el MVP se distribuye sin ofuscación; reglas de seguridad básicas)
-keep class com.albionflip.assistant.photon.** { *; }
-keep class com.albionflip.assistant.albion.** { *; }
