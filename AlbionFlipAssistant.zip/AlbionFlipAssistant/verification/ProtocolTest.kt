import com.albionflip.assistant.albion.GameCodes
import com.albionflip.assistant.albion.MarketOrder
import com.albionflip.assistant.photon.PhotonParser
import java.io.ByteArrayOutputStream

/**
 * Prueba del decodificador Photon/Protocol18 con paquetes sintéticos
 * construidos según el formato verificado en albiondata-client (parser.go).
 *
 * Compila con kotlinc + org.json y valida:
 *  A) Órdenes de mercado en la posición del mensaje de depuración (formato actual)
 *  B) Órdenes en la tabla de parámetros (formato histórico, opcode legacy)
 *  C) Reensamblado de fragmentos
 *  D) CRC variante Photon (acepta CRC correcto, rechaza CRC corrupto)
 *  E) Tabla de parámetros con tipos mixtos (string/int2/compressedLong/bool)
 *  F) Normalización y nombres de ubicaciones
 *  G) Detección de paquetes cifrados
 */

// ── Codificadores sintéticos (espejo del formato real) ──────────────────────

class W {
    val out = ByteArrayOutputStream()
    fun b(v: Int) { out.write(v and 0xFF) }
    fun bytes(v: ByteArray) { out.write(v) }
    fun u16be(v: Int) { b(v shr 8); b(v) }
    fun u32be(v: Long) { b((v shr 24).toInt()); b((v shr 16).toInt()); b((v shr 8).toInt()); b(v.toInt()) }
    fun u16le(v: Int) { b(v); b(v shr 8) }
    fun u32le(v: Long) { b(v.toInt()); b((v shr 8).toInt()); b((v shr 16).toInt()); b((v shr 24).toInt()) }
    fun varint(v0: Long) {
        var v = v0
        while (true) {
            val bits = (v and 0x7F).toInt()
            v = v ushr 7
            if (v == 0L) { b(bits); return }
            b(bits or 0x80)
        }
    }
    fun zigzag64(n: Long): Long = (n shl 1) xor (n shr 63)
    fun toBytes(): ByteArray = out.toByteArray()
}

fun encString(s: String, w: W) {
    val raw = s.toByteArray(Charsets.UTF_8)
    w.varint(raw.size.toLong())
    w.bytes(raw)
}

/** Tabla de parámetros: varint(cant) | (clave | tipo | valor)* */
fun encParamTable(entries: List<Triple<Int, Int, Any>>): ByteArray {
    val w = W()
    w.varint(entries.size.toLong())
    for ((key, type, value) in entries) {
        w.b(key); w.b(type)
        when (type) {
            7 -> encString(value as String, w)                       // string
            11 -> w.b(value as Int)                                  // int 1 byte
            13 -> w.u16le(value as Int)                              // int 2 bytes LE
            17 -> w.u16le(value as Int)                              // long 2 bytes LE
            28 -> Unit                                               // bool true (sin payload)
            10 -> w.varint(w.zigzag64(value as Long))                // compressedLong zigzag
            0x47 -> {                                                // array tipado de strings
                @Suppress("UNCHECKED_CAST")
                val arr = value as Array<String>
                w.varint(arr.size.toLong())
                for (s in arr) encString(s, w)
            }
            else -> throw IllegalArgumentException("tipo no soportado en el test: $type")
        }
    }
    return w.toBytes()
}

/** OperationResponse: opcode | returnCode LE | [depuración: tipo+valor] | tabla de parámetros.
 *  Según el fixture real de albiondata-client (decode_reliable_photon_test.go),
 *  cuando no hay mensaje de depuración el juego envía un byte TypeNull (0x08). */
fun encOperationResponse(
    opcode: Int,
    debug: Pair<Int, Any>? = null,   // (tipo, valor)
    params: List<Triple<Int, Int, Any>> = emptyList()
): ByteArray {
    val w = W()
    w.b(opcode)
    w.u16le(0)  // returnCode 0
    if (debug != null) {
        w.b(debug.first); w.b(debug.second as Int)
    } else {
        w.b(0x08)    // TypeNull: posición de depuración presente, sin valor
    }
    if (params.isNotEmpty()) w.bytes(encParamTable(params))
    return w.toBytes()
}

/** Comando reliable: header 12B + signalByte + msgType + datos */
fun encReliableCommand(seq: Int, msgType: Int, data: ByteArray): ByteArray {
    val w = W()
    w.b(6)               // cmdSendReliable
    w.b(0)               // canal
    w.b(0)               // flags de comando
    w.b(0)               // reservado
    w.u32be((12 + 2 + data.size).toLong())
    w.u32be(seq.toLong())
    w.b(0)               // signalByte
    w.b(msgType)         // 3 = OperationResponse
    w.bytes(data)
    return w.toBytes()
}

/** Comando de fragmento: header 12B + header 20B + trozo */
fun encFragmentCommand(seq: Int, startSeq: Int, fragCount: Int, fragNumber: Int,
                       totalLen: Int, fragOffset: Int, chunk: ByteArray): ByteArray {
    val w = W()
    w.b(8)               // cmdSendFragment
    w.b(0); w.b(0); w.b(0)
    w.u32be((12 + 20 + chunk.size).toLong())
    w.u32be(seq.toLong())
    w.u32be(startSeq.toLong())
    w.u32be(fragCount.toLong())
    w.u32be(fragNumber.toLong())
    w.u32be(totalLen.toLong())
    w.u32be(fragOffset.toLong())
    w.bytes(chunk)
    return w.toBytes()
}

/** Paquete Photon: peerId BE | flags | cmdCount | timestamp | challenge | comandos [| CRC] */
fun encPacket(commands: List<ByteArray>, flags: Int = 0): ByteArray {
    val w = W()
    w.u16be(7)           // peerId
    w.b(flags)
    w.b(commands.size)
    w.u32be(0)           // timestamp
    w.u32be(0x11223344L) // challenge
    for (c in commands) w.bytes(c)
    val pkt = w.toBytes()
    if (flags == 0xCC) {
        // Paquete completo con el campo CRC (4 bytes tras el header de 12) a cero,
        // calcular CRC sobre él y parchear el campo (igual que hace el parser).
        val full = ByteArray(pkt.size + 4)
        System.arraycopy(pkt, 0, full, 0, 12)
        System.arraycopy(pkt, 12, full, 16, pkt.size - 12)  // comandos tras el campo CRC
        var crc = 0xFFFFFFFFL
        val key = 3988292384L
        for (byte in full) {
            crc = crc xor (byte.toLong() and 0xFF)
            for (j in 0 until 8) {
                crc = if (crc and 1L != 0L) (crc ushr 1) xor key else crc ushr 1
            }
        }
        full[12] = ((crc shr 24) and 0xFF).toByte()
        full[13] = ((crc shr 16) and 0xFF).toByte()
        full[14] = ((crc shr 8) and 0xFF).toByte()
        full[15] = (crc and 0xFF).toByte()
        return full
    }
    return pkt
}

// ── Utilidades de aserción ──────────────────────────────────────────────────

var failures = 0
fun check(name: String, cond: Boolean, detail: String = "") {
    if (cond) {
        println("OK   $name")
    } else {
        println("FALLO $name $detail")
        failures++
    }
}

// ── Pruebas ─────────────────────────────────────────────────────────────────

const val JSON_OFFER = "{\"Id\":55,\"ItemTypeId\":\"T6_BAG@2\",\"ItemGroupTypeId\":\"Bags\"," +
        "\"LocationId\":null,\"QualityLevel\":1,\"EnchantmentLevel\":2,\"UnitPriceSilver\":123456," +
        "\"Amount\":7,\"AuctionType\":\"offer\",\"Expires\":\"2026-11-20T00:00:00Z\"}"
const val JSON_OFFER2 = "{\"Id\":56,\"ItemTypeId\":\"T8_MAIN_SWORD@1\",\"ItemGroupTypeId\":\"Swords\"," +
        "\"LocationId\":\"BLACKBANK-99\",\"QualityLevel\":3,\"EnchantmentLevel\":1,\"UnitPriceSilver\":9999999," +
        "\"Amount\":1,\"AuctionType\":\"offer\",\"Expires\":\"2026-11-21T00:00:00Z\"}"
const val JSON_REQUEST = "{\"Id\":77,\"ItemTypeId\":\"T4_HIDE\",\"ItemGroupTypeId\":\"Hide\"," +
        "\"LocationId\":null,\"QualityLevel\":1,\"EnchantmentLevel\":0,\"UnitPriceSilver\":500," +
        "\"Amount\":100,\"AuctionType\":\"request\",\"Expires\":\"2026-11-22T00:00:00Z\"}"

fun main() {
    // ── A) Órdenes en la posición de depuración (formato actual de Albion) ──
    run {
        val parser = PhotonParser()
        var gotOp = -1
        var gotOrders: Array<out Any?>? = null
        parser.onResponse = { op, _, _, params ->
            gotOp = op
            gotOrders = params[0] as? Array<*>
        }
        val resp = encOperationResponse(81, debug = Pair(0x47, 0x47), params = emptyList())
        // sustituir: el valor de depuración es un array de strings; lo codificamos a mano
        val data = manualResponseWithDebugStringArray(81, arrayOf(JSON_OFFER, JSON_OFFER2))
        val pkt = encPacket(listOf(encReliableCommand(1, 3, data)))
        parser.receivePacket(pkt)

        check("A: opcode 81 detectado", gotOp == 81, "(got $gotOp)")
        val orders = gotOrders
        check("A: 2 órdenes recibidas", orders != null && orders.size == 2)
        val o1 = orders?.get(0)?.let { MarketOrder.fromJson(it as String, "3005") }
        check("A: item decodificado", o1?.itemId == "T6_BAG@2", "(got ${o1?.itemId})")
        check("A: encantamiento 2", o1?.enchantment == 2, "(got ${o1?.enchantment})")
        check("A: precio 123456", o1?.unitPrice == 123456L, "(got ${o1?.unitPrice})")
        check("A: ubicación nula → ubicación del jugador (3005)", o1?.locationId == "3005", "(got ${o1?.locationId})")
        check("A: tipo offer", o1?.auctionType == "offer", "(got ${o1?.auctionType})")
        val o2 = orders?.get(1)?.let { MarketOrder.fromJson(it as String, "3005") }
        check("A: M. Negro conserva su ubicación", o2?.locationId == "BLACKBANK-99", "(got ${o2?.locationId})")
    }

    // ── B) Órdenes en la tabla de parámetros (formato histórico) ────────────
    run {
        val parser = PhotonParser()
        var gotOrders: Array<out Any?>? = null
        parser.onResponse = { op, _, _, params ->
            if (op == 76) gotOrders = params[0] as? Array<*>
        }
        val data = encOperationResponse(76, params = listOf(Triple(0, 0x47, arrayOf(JSON_OFFER, JSON_REQUEST))))
        val pkt = encPacket(listOf(encReliableCommand(2, 3, data)))
        parser.receivePacket(pkt)
        val orders = gotOrders
        check("B: 2 órdenes via tabla de parámetros", orders != null && orders.size == 2)
        val req = orders?.get(1)?.let { MarketOrder.fromJson(it as String, "3005") }
        check("B: orden de compra (request)", req?.auctionType == "request", "(got ${req?.auctionType})")
        check("B: calidad 1", req?.quality == 1)
    }

    // ── C) Reensamblado de fragmentos ───────────────────────────────────────
    run {
        val parser = PhotonParser()
        var calls = 0
        var orders = 0
        parser.onResponse = { _, _, _, params ->
            calls++
            val arr = params[0] as? Array<*>
            orders = arr?.size ?: 0
        }
        // 50 JSON de órdenes en param 0 → mensaje grande → 3 fragmentos.
        // IMPORTANTE: lo que se fragmenta es el PAYLOAD del comando reliable
        // (signalByte + msgType + datos), no solo los datos de la respuesta.
        val jsons = Array(50) { i ->
            JSON_OFFER.replace("\"Id\":55", "\"Id\":${100 + i}")
        }
        val response = encOperationResponse(82, params = listOf(Triple(0, 0x47, jsons)))
        val reliablePayload = byteArrayOf(0x00, 0x03) + response   // señal + tipo 3 (Response)
        val total = reliablePayload.size
        val chunkSize = total / 3 + 1
        val cmds = ArrayList<ByteArray>()
        var off = 0
        var frag = 0
        while (off < total) {
            val len = minOf(chunkSize, total - off)
            cmds.add(encFragmentCommand(10 + frag, 500, 3, frag, total, off, reliablePayload.copyOfRange(off, off + len)))
            off += len
            frag++
        }
        val pkt = encPacket(cmds)
        parser.receivePacket(pkt)
        check("C: un solo mensaje reensamblado", calls == 1, "(calls=$calls)")
        check("C: 50 órdenes reconstruidas", orders == 50, "(orders=$orders)")
    }

    // ── D) CRC ──────────────────────────────────────────────────────────────
    run {
        val parser = PhotonParser()
        var got = false
        parser.onResponse = { _, _, _, _ -> got = true }
        val data = encOperationResponse(81, params = listOf(Triple(0, 0x47, arrayOf(JSON_OFFER))))
        val ok = encPacket(listOf(encReliableCommand(3, 3, data)), flags = 0xCC)
        check("D: CRC correcto aceptado", parser.receivePacket(ok) && got)

        val bad = ok.copyOf()
        bad[bad.size - 1] = (bad[bad.size - 1] + 1).toByte()
        got = false
        check("D: CRC corrupto rechazado", !parser.receivePacket(bad) && !got)
    }

    // ── E) Tabla de parámetros con tipos mixtos ─────────────────────────────
    run {
        val parser = PhotonParser()
        var city = ""
        var count = 0
        var big = 0L
        var flag = false
        parser.onResponse = { _, _, _, params ->
            city = params[1] as? String ?: ""
            count = params[2] as? Int ?: -1
            big = params[3] as? Long ?: -1L
            flag = params[4] as? Boolean ?: false
        }
        val data = encOperationResponse(
            2,
            params = listOf(
                Triple(1, 7, "Caerleon"),
                Triple(2, 13, 50000),
                Triple(3, 10, 900000L),
                Triple(4, 28, true)
            )
        )
        val pkt = encPacket(listOf(encReliableCommand(4, 3, data)))
        parser.receivePacket(pkt)
        check("E: string LE/varint", city == "Caerleon", "(got '$city')")
        check("E: int2 LE", count == 50000, "(got $count)")
        check("E: compressedLong zigzag", big == 900000L, "(got $big)")
        check("E: bool true", flag)
    }

    // ── F) Ubicaciones ──────────────────────────────────────────────────────
    run {
        check("F: 3005 = Caerleon", GameCodes.locationName("3005") == "Caerleon")
        check("F: 0007 = Thetford", GameCodes.locationName("0007") == "Thetford")
        check("F: BLACKBANK → Mercado Negro",
            GameCodes.locationName("BLACKBANK-99") == "Mercado Negro")
        check("F: dígito válido se conserva", GameCodes.normalizeLocation("4002") == "4002")
        check("F: basura rechazada", GameCodes.normalizeLocation("hola-mundo!") == null)
        check("F: isla aceptada",
            GameCodes.normalizeLocation("@island@12345678-1234-1234-1234-123456789abc")?.startsWith("@ISLAND@") == true)
    }

    // ── G) Cifrado ──────────────────────────────────────────────────────────
    run {
        val parser = PhotonParser()
        var encCalls = 0
        parser.onEncrypted = { encCalls++ }
        val w = W()
        w.u16be(7); w.b(1); w.b(0); w.u32be(0); w.u32be(0x11223344L)
        parser.receivePacket(w.toBytes())
        check("G: flag cifrado detectado", encCalls == 1)
    }

    println(if (failures == 0) "\nTODAS LAS PRUEBAS PASARON" else "\n$failures PRUEBAS FALLARON")
    if (failures > 0) kotlin.system.exitProcess(1)
}

/**
 * Codifica una OperationResponse cuyo campo de depuración es un array tipado
 * de strings (0x47) — exactamente donde Albion embebe las órdenes de mercado.
 */
fun manualResponseWithDebugStringArray(opcode: Int, orders: Array<String>): ByteArray {
    val w = W()
    w.b(opcode)
    w.u16le(0)
    w.b(0x47)                // tipo: array tipado de strings
    w.varint(orders.size.toLong())
    for (s in orders) encString(s, w)
    // sin tabla de parámetros adicional
    return w.toBytes()
}
