# Albion Flip Assistant

Asistente Android de **flippin** para Albion Online (servidor Américas). La app escucha de forma **pasiva** el tráfico del juego en tu propio teléfono (VPN local, sin root), guarda las órdenes de los mercados que abres en el juego, las combina con datos comunitarios de AODP, calcula oportunidades de flippin y te **alerta** cuando aparece una oferta que supera tus umbrales.

> **No es un bot.** La app nunca opera el juego: no compra, no vende, no toca nada. Solo lee datos de red, analiza y avisa. La compra la haces tú dentro del juego.

---

## Qué hace

| Función | Estado en este MVP |
|---|---|
| Captura del tráfico del juego en el móvil (VPN local sin root) | ✅ VpnService + router propio (UDP y TCP) |
| Decodificación del protocolo Photon de Albion (Protocol18) | ✅ Puerto verificado de `albiondata-client` con suite de pruebas |
| Órdenes de mercado: ciudad ↔ Mercado Negro, ciudad ↔ Caerleon, encantamientos | ✅ (opciones configurables) |
| Datos comunitarios AODP (west = Américas) para rellenar mercados no escaneados | ✅ |
| Panel en vivo ordenado por ganancia + filtros por ruta | ✅ |
| Notificaciones de ofertas nuevas (con deduplicación de 5 min) | ✅ |
| Historial básico de escaneos y alertas | ✅ |
| Umbrales configurables (ganancia mínima, margen mínimo) e impuestos editables | ✅ |
| Auto-compra / cualquier automatización del juego | ❌ (no lo hagas: es baneable) |

## Qué NO hace (limitaciones honestas)

- **No hay auto-compra ni bot**, por diseño y por reglas del juego.
- **Mercados que no abres**: tus datos en tiempo real son de los mercados que navegas. El resto se rellena con AODP (datos agregados de otros jugadores, con retraso).
- **Si SBI cifra los datos de mercado** en alguna build, ningún cliente pasivo puede leerlos — la app lo detecta y te avisa (misma limitación que el cliente oficial de AODP). Cuando vuelven en claro, la captura sigue sola.
- **IPv6**: la captura cubre IPv4 (el juego conecta por IPv4/Photon UDP). Si tu red fuerza IPv6, los datos pueden no llegar.
- El proxy TCP es intencionalmente simple (MVP). Si un flujo TCP falla, reinicia la captura.

## Requisitos para compilar

1. **Android Studio** (Koala o más nuevo) con **JDK 17** (el incluido en Studio sirve).
2. Un dispositivo o emulador con **Android 8.0 (API 26) o superior**.
3. Internet para descargar dependencias (se descargan solas al sincronizar).

## Cómo compilar

**Opción A — Android Studio (recomendado):**
1. `File → Open` y selecciona la carpeta `AlbionFlipAssistant`.
2. Espera la sincronización de Gradle (primera vez descarga dependencias).
3. `Run ▶` con tu dispositivo conectado (activa "Depuración USB").

**Opción B — línea de comandos:**
```bash
cd AlbionFlipAssistant
./gradlew assembleDebug
# el APK queda en app/build/outputs/apk/debug/app-debug.apk
adb install app/build/outputs/apk/debug/app-debug.apk
```

> Si `./gradlew` falla por permisos: `chmod +x gradlew`.
> No necesitas `local.properties`: Android Studio lo crea solo.

### Compilar SIN PC (solo con tu teléfono Android)

El proyecto incluye `.github/workflows/build-apk.yml`: GitHub compila el APK **en sus servidores gratis** y te lo deja descargable. Pasos completos desde el móvil:

1. Crea una cuenta gratis en **github.com** (desde el navegador del teléfono).
2. Toca el `+` → **New repository** → nombre p. ej. `albion-flip-assistant` → **Public** → Create.
3. En la página del repo: **"uploading an existing file"** (Add file → Upload files).
4. En el selector de archivos del teléfono, entra a la carpeta descomprimida `AlbionFlipAssistant` y **selecciona TODO su contenido** (mantén pulsado un archivo para activar la multiselección; incluye la carpeta `.github` y `app` completas — si tu explorador no deja subir carpetas, sube primero las de adentro; la estructura de rutas debe quedar igual que en el proyecto).
5. **Commit changes** → GitHub detecta el workflow y arranca la compilación sola.
6. Pestaña **Actions** → espera 5–15 min → toca el build → baja a **Artifacts** → descarga `AlbionFlipAssistant-apk` (es un ZIP con el APK adentro).
7. Descomprime, toca el APK → Android te pedirá permitir "instalar apps desconocidas" para el navegador → instálalo.
8. Al abrir la app: permiso de notificaciones y, al iniciar la captura, el diálogo de VPN.

**Si la compilación falla:** abre el build en Actions y lee el error en rojo; normalmente es un archivo que faltó al subir (revisa que `app/build.gradle.kts`, `gradle/` y todos los `.kt` estén en sus rutas). Copia el log de error y se corrige en un minuto.

**Alternativa en la nube:** Gitpod.io o GitHub Codespaces abren el proyecto en un VS Code del navegador con terminal Linux; ahí basta `chmod +x gradlew && ./gradlew assembleDebug` y descargas `app/build/outputs/apk/debug/app-debug.apk` desde el explorador de archivos.

**Aviso:** AIDE y otros "IDEs para Android en el móvil" **no** pueden compilar este proyecto (usan Gradle/AGP antiguos sin Kotlin 2.0 ni Compose). La vía fiable sin PC es la nube (GitHub Actions).

## Cómo usar (flujo real de flippin)

1. Abre la app → pestaña **En vivo** → **Iniciar captura** → acepta el diálogo de VPN del sistema.
2. Juega Albion normalmente **en el mismo teléfono**. Cada mercado que abras en el juego alimenta el análisis:
   - Para flippin de **Mercado Negro**: abre el Mercado Negro en Caerleon (o navega sus órdenes) y también los mercados de las ciudades donde compras.
   - Para **Caerleon**: navega los mercados de Caerleon y de las ciudades reales.
   - La app detecta tu ubicación automáticamente al cambiar de zona (aparece en el panel).
3. Ajusta en **Ajustes** tu ganancia mínima (por defecto 20 000 de plata) y el margen mínimo.
4. Las oportunidades aparecen en el panel en vivo, ordenadas por ganancia; si una nueva supera los umbrales llega una **notificación**.
5. **Actualizar AODP** consulta precios comunitarios para los items ya conocidos (útil para la primera pasada del día).
6. La compra y el transporte los haces tú en el juego. La app es tu radar, no tus manos.

**Consejo práctico:** para escanear rápido una ciudad, entra al mercado y pasa por las categorías (armas, armaduras, recursos, consumibles). Cada pantalla que cargas sube el libro de órdenes completo a tu base local.

## Arquitectura técnica

```
VpnCaptureService (VpnService, foreground)
   └─ PacketRouter        → lee el TUN, reenvía todo intacto (UDP por NAT, TCP por proxy)
        └─ payloads UDP → PhotonParser (formato binario Photon + CRC + fragmentos)
             └─ Protocol18 (deserialización de tipos, varints, zigzag)
                  └─ GamePacketListener
                       ├─ opcode 81/82 (AuctionGetOffers/Requests) → órdenes JSON → CaptureBus
                       ├─ opcode 2 (Join, param 8)                → ubicación actual
                       └─ paquete cifrado (0x83 / flag 1)          → aviso en UI
CaptureBus (estado compartido: libros de órdenes, contadores, flips en vivo)
   ├─ FlipEngine  → rutas M. Negro / Caerleon / Encantamientos con impuestos configurables
   ├─ AlertManager → notificaciones con deduplicación
   ├─ AodpClient  → west.albion-online-data.com (Américas)
   └─ FlipDb      → historial de escaneos y alertas (SQLite)
UI Compose: En vivo / Historial / Ajustes
```

**Referencias verificadas** (código abierto, usadas como especificación):
- `ao-data/albiondata-client` (MIT) — formato binario Photon/Protocol18, códigos de operación actuales (`AuctionGetOffers=81`, `AuctionGetRequests=82`, `Join=2`), JSON de cada orden (`ItemTypeId`, `UnitPriceSilver`, `QualityLevel`, `EnchantmentLevel`, `AuctionType`, `LocationId`…), detección de cifrado.
- `Triky313/AlbionOnline-StatisticsAnalysis` (GPL-3.0) — mapeo de IDs numéricos de ubicaciones (3005=Caerleon, 0007=Thetford, BLACKBANK-=Mercado Negro, etc.).
- `albion-online-data.com` — API pública de precios (host `west.` para Américas).
- `ao-data/ao-bin-dumps` — nombres de objetos (`assets/item_names.txt`, en inglés, estándar de la comunidad).

**Verificación del decodificador:** `verification/ProtocolTest.kt` construye paquetes sintéticos (órdenes actuales e históricas, fragmentación, CRC, tipos mixtos, cifrado) y valida el decodificador extremo a extremo. 26/26 pruebas pasan. Para ejecutarlo necesitas `kotlinc` + `org.json` (las instrucciones están como comentario en el propio archivo).

## Mantenimiento y calibración

- **Códigos de operación**: si SBI renumera operaciones en un parche, actualiza `GameCodes.kt`. Como defensa, el listener también valida la *forma* de los datos (array de strings JSON con `ItemTypeId`), así que suele seguir funcionando aunque cambien los números. Compara con `ao-data/albiondata-client` tras cada parche grande.
- **Impuestos**: por defecto 3% de venta y 2,5% de publicación. Revisa los valores vigentes tras cada parche económico y ajústalos en **Ajustes** (la app no los descubre sola).
- **IDs de ubicación**: si se añaden ciudades, amplía el mapeo en `GameCodes.kt`.
- **Calidad**: las órdenes del Mercado Negro traen calidad explícita; el comparador exige mismo item + misma calidad.

## Avisos importantes

- Herramienta no oficial. **No afiliada a Sandbox Interactive**; todos los assets y datos del juego son propiedad de SBI GmbH.
- La lectura pasiva del tráfico del juego es la misma que usan el Albion Online Data Project y Albion Free Market; según el propio proyecto, no es una infracción para SBI. Dicho esto, úsala bajo tu propio criterio.
- Código de referencia: `albiondata-client` es MIT (respeta su licencia y atribución); el mapeo de ubicaciones proviene de un proyecto GPL-3.0 — si distribuyes esta app, revisa la compatibilidad de licencias.
- El flippin es un juego de velocidad contra otros miles de usuarios con herramientas similares; un asistente privado y local (como este) es tu ventaja, no una máquina de plata garantizada.
